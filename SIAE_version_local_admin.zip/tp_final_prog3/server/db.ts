import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

export interface Usuario {
  id_usuario: number;
  nombre_usuario: string;
  password_hash: string;
  rol: 'administrador' | 'docente' | 'preceptor';
  nombre_completo: string;
  email: string;
}

export interface Curso {
  id_curso: number;
  anio: number; // 1, 2, 3
  division: string; // A, B, C
  turno: 'Mañana' | 'Tarde' | 'Vespertino';
  especialidad?: string;
}

export interface Estudiante {
  id_estudiante: number;
  dni: string;
  apellido: string;
  nombre: string;
  id_curso: number;
  estado: boolean; // true = activo, false = inactivo
  telefono_tutor?: string;
  email_tutor?: string;
}

export interface Asistencia {
  id_asistencia: number;
  id_estudiante: number;
  fecha: string; // YYYY-MM-DD
  estado: 'P' | 'A' | 'T' | 'AJ'; // Presente, Ausente, Tardanza, Ausente justificado
  observacion?: string;
  id_usuario: number; // usuario que registró
  jornada: 'Mañana' | 'Tarde';
  creado_el?: string;
}

export interface DatabaseSchema {
  usuarios: Usuario[];
  cursos: Curso[];
  estudiantes: Estudiante[];
  asistencias: Asistencia[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'siae_database.json');

class RelationalDatabase {
  private data: DatabaseSchema;

  constructor() {
    this.data = {
      usuarios: [],
      cursos: [],
      estudiantes: [],
      asistencias: []
    };
    this.init();
  }

  private init() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(raw);
        // Ensure all tables exist
        if (!this.data.usuarios) this.data.usuarios = [];
        if (!this.data.cursos) this.data.cursos = [];
        if (!this.data.estudiantes) this.data.estudiantes = [];
        if (!this.data.asistencias) this.data.asistencias = [];
      } else {
        this.seedInitialData();
      }
    } catch (err) {
      console.error('Error initializing database file, recreating seed:', err);
      this.seedInitialData();
    }
  }

  public persist() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error persisting database:', err);
    }
  }

  public seedInitialData(forceReset: boolean = false) {
    if (this.data.usuarios.length > 0 && !forceReset) return;

    console.log('Seeding SIAE relational database with technical school records...');

    // 1. Usuarios con password_hash (bcrypt)
    const salt = bcrypt.genSaltSync(10);
    const usuarios: Usuario[] = [
      {
        id_usuario: 1,
        nombre_usuario: 'admin',
        password_hash: bcrypt.hashSync('admin123', salt),
        rol: 'administrador',
        nombre_completo: 'Prof. Carlos Gutiérrez (Rector)',
        email: 'rectoria@eest6.edu.ar'
      },
    ];

    // 2. Cursos de 1.º, 2.º y 3.º año
    const cursos: Curso[] = [
      { id_curso: 1, anio: 1, division: 'A', turno: 'Mañana', especialidad: 'Ciclo Básico' },
      { id_curso: 2, anio: 1, division: 'B', turno: 'Mañana', especialidad: 'Ciclo Básico' },
      { id_curso: 3, anio: 1, division: 'C', turno: 'Tarde', especialidad: 'Ciclo Básico' },
      { id_curso: 4, anio: 2, division: 'A', turno: 'Mañana', especialidad: 'Ciclo Básico' },
      { id_curso: 5, anio: 2, division: 'B', turno: 'Tarde', especialidad: 'Ciclo Básico' },
      { id_curso: 6, anio: 2, division: 'C', turno: 'Mañana', especialidad: 'Ciclo Básico' },
      { id_curso: 7, anio: 3, division: 'A', turno: 'Mañana', especialidad: 'Introducción a Programación' },
      { id_curso: 8, anio: 3, division: 'B', turno: 'Tarde', especialidad: 'Introducción a Programación' },
      { id_curso: 9, anio: 3, division: 'C', turno: 'Mañana', especialidad: 'Introducción a Programación' }
    ];

    // 3. Estudiantes
    const nombresEjemplo = [
      { ape: 'Álvarez', nom: 'Mateo', dni: '48912340', c: 1 },
      { ape: 'Benítez', nom: 'Valentina', dni: '48912341', c: 1 },
      { ape: 'Castro', nom: 'Thiago', dni: '48912342', c: 1 },
      { ape: 'Díaz', nom: 'Sofía', dni: '48912343', c: 1 },
      { ape: 'Espósito', nom: 'Joaquín', dni: '48912344', c: 1 },
      { ape: 'Fernández', nom: 'Martina', dni: '48912345', c: 1 },

      { ape: 'García', nom: 'Lucas', dni: '48922301', c: 2 },
      { ape: 'Herrera', nom: 'Camila', dni: '48922302', c: 2 },
      { ape: 'Ibarra', nom: 'Lautaro', dni: '48922303', c: 2 },
      { ape: 'Juárez', nom: 'Emma', dni: '48922304', c: 2 },
      { ape: 'López', nom: 'Benjamín', dni: '48922305', c: 2 },

      { ape: 'Mendoza', nom: 'Zoe', dni: '48933410', c: 3 },
      { ape: 'Navarro', nom: 'Agustín', dni: '48933411', c: 3 },
      { ape: 'Ortiz', nom: 'Mia', dni: '48933412', c: 3 },
      { ape: 'Pérez', nom: 'Santino', dni: '48933413', c: 3 },
      { ape: 'Quiroga', nom: 'Lucía', dni: '48933414', c: 3 },

      { ape: 'Rodríguez', nom: 'Emiliano', dni: '47844501', c: 4 },
      { ape: 'Sánchez', nom: 'Julieta', dni: '47844502', c: 4 },
      { ape: 'Torres', nom: 'Bautista', dni: '47844503', c: 4 },
      { ape: 'Urquiza', nom: 'Catalina', dni: '47844504', c: 4 },
      { ape: 'Vázquez', nom: 'Felipe', dni: '47844505', c: 4 },

      { ape: 'Williams', nom: 'Delfina', dni: '47855610', c: 5 },
      { ape: 'Yáñez', nom: 'Tomás', dni: '47855611', c: 5 },
      { ape: 'Zamora', nom: 'Renata', dni: '47855612', c: 5 },
      { ape: 'Acosta', nom: 'Ignacio', dni: '47855613', c: 5 },

      { ape: 'Bustos', nom: 'Morena', dni: '47866701', c: 6 },
      { ape: 'Cabral', nom: 'Facundo', dni: '47866702', c: 6 },
      { ape: 'Domínguez', nom: 'Alma', dni: '47866703', c: 6 },
      { ape: 'Funes', nom: 'Ramiro', dni: '47866704', c: 6 },

      { ape: 'Gómez', nom: 'Franco', dni: '46777801', c: 7 },
      { ape: 'Heredia', nom: 'Abril', dni: '46777802', c: 7 },
      { ape: 'Insaurralde', nom: 'Nicolás', dni: '46777803', c: 7 },
      { ape: 'Jara', nom: 'Victoria', dni: '46777804', c: 7 },
      { ape: 'Ledesma', nom: 'Gonzalo', dni: '46777805', c: 7 },
      { ape: 'Molina', nom: 'Pilar', dni: '46777806', c: 7 },

      { ape: 'Núñez', nom: 'Alejo', dni: '46788910', c: 8 },
      { ape: 'Ojeda', nom: 'Malena', dni: '46788911', c: 8 },
      { ape: 'Peralta', nom: 'Esteban', dni: '46788912', c: 8 },
      { ape: 'Quinteros', nom: 'Constanza', dni: '46788913', c: 8 },

      { ape: 'Ríos', nom: 'Tobías', dni: '46799001', c: 9 },
      { ape: 'Salas', nom: 'Guadalupe', dni: '46799002', c: 9 },
      { ape: 'Toledo', nom: 'Ezequiel', dni: '46799003', c: 9 },
      { ape: 'Vega', nom: 'Solana', dni: '46799004', c: 9 },
      { ape: 'Zárate', nom: 'Jeremías', dni: '46799005', c: 9 }
    ];

    const estudiantes: Estudiante[] = nombresEjemplo.map((item, idx) => ({
      id_estudiante: idx + 1,
      dni: item.dni,
      apellido: item.ape,
      nombre: item.nom,
      id_curso: item.c,
      estado: true,
      telefono_tutor: `11-${Math.floor(4000 + Math.random() * 5000)}-${Math.floor(1000 + Math.random() * 9000)}`,
      email_tutor: `tutor.${item.ape.toLowerCase()}@gmail.com`
    }));

    // 4. Asistencias históricas para dar vida al sistema
    const asistencias: Asistencia[] = [];
    let idAsistenciaCounter = 1;

    // Fechas de ejemplo en las últimas dos semanas escolares
    const fechas = [
      '2026-10-26',
      '2026-10-27',
      '2026-10-28',
      '2026-10-29',
      '2026-10-30',
      '2026-11-02',
      '2026-11-03',
      '2026-11-04'
    ];

    // Seed realistic attendance pattern
    for (const fecha of fechas) {
      for (const est of estudiantes) {
        const curso = cursos.find(c => c.id_curso === est.id_curso);
        const jornada = (curso?.turno === 'Tarde') ? 'Tarde' : 'Mañana';

        // Distribution: 82% Presente, 10% Ausente, 5% Tardanza, 3% Ausente Justificado
        const rand = Math.random();
        let estado: 'P' | 'A' | 'T' | 'AJ' = 'P';
        let observacion = '';

        // Simulate some students with higher absenteeism (e.g. Álvarez Mateo, Toledo Ezequiel)
        if (est.id_estudiante === 1 || est.id_estudiante === 42) {
          if (rand < 0.40) {
            estado = 'A';
            observacion = 'Sin aviso';
          } else if (rand < 0.60) {
            estado = 'AJ';
            observacion = 'Certificado médico presentado';
          } else if (rand < 0.75) {
            estado = 'T';
            observacion = 'Llegó con 20 minutos de demora';
          } else {
            estado = 'P';
          }
        } else {
          if (rand < 0.08) {
            estado = 'A';
          } else if (rand < 0.12) {
            estado = 'T';
            observacion = 'Demora por transporte público';
          } else if (rand < 0.15) {
            estado = 'AJ';
            observacion = 'Consulta odontológica justificada';
          } else {
            estado = 'P';
          }
        }

        asistencias.push({
          id_asistencia: idAsistenciaCounter++,
          id_estudiante: est.id_estudiante,
          fecha,
          estado,
          observacion: observacion || undefined,
          id_usuario: 1, // Administrador
          jornada,
          creado_el: new Date().toISOString()
        });
      }
    }

    this.data = {
      usuarios,
      cursos,
      estudiantes,
      asistencias
    };

    this.persist();
  }

  // ================= USUARIOS =================
  public getUsuarios(): Omit<Usuario, 'password_hash'>[] {
    return this.data.usuarios.map(({ password_hash, ...u }) => u);
  }

  public getUsuarioByUsername(username: string): Usuario | undefined {
    return this.data.usuarios.find(u => u.nombre_usuario.toLowerCase() === username.toLowerCase());
  }

  public getUsuarioById(id: number): Usuario | undefined {
    return this.data.usuarios.find(u => u.id_usuario === id);
  }

  // ================= CURSOS =================
  public getCursos(): (Curso & { cantidad_estudiantes: number })[] {
    return this.data.cursos.map(c => {
      const cantidad = this.data.estudiantes.filter(e => e.id_curso === c.id_curso && e.estado).length;
      return {
        ...c,
        cantidad_estudiantes: cantidad
      };
    }).sort((a, b) => a.anio - b.anio || a.division.localeCompare(b.division));
  }

  public getCursoById(id: number): Curso | undefined {
    return this.data.cursos.find(c => c.id_curso === id);
  }

  public createCurso(data: Omit<Curso, 'id_curso'>): Curso {
    const existing = this.data.cursos.find(
      c => c.anio === data.anio && c.division.toUpperCase() === data.division.toUpperCase() && c.turno === data.turno
    );
    if (existing) {
      throw new Error(`Ya existe un curso para ${data.anio}° año División ${data.division.toUpperCase()} en turno ${data.turno}.`);
    }

    const nextId = this.data.cursos.reduce((max, c) => Math.max(max, c.id_curso), 0) + 1;
    const newCurso: Curso = {
      id_curso: nextId,
      anio: Number(data.anio),
      division: data.division.trim().toUpperCase(),
      turno: data.turno,
      especialidad: data.especialidad || (data.anio === 3 ? 'Introducción a Programación' : 'Ciclo Básico')
    };

    this.data.cursos.push(newCurso);
    this.persist();
    return newCurso;
  }

  public updateCurso(id: number, data: Partial<Omit<Curso, 'id_curso'>>): Curso {
    const curso = this.data.cursos.find(c => c.id_curso === id);
    if (!curso) throw new Error('Curso no encontrado');

    if (data.anio !== undefined) curso.anio = Number(data.anio);
    if (data.division !== undefined) curso.division = data.division.trim().toUpperCase();
    if (data.turno !== undefined) curso.turno = data.turno;
    if (data.especialidad !== undefined) curso.especialidad = data.especialidad;

    this.persist();
    return curso;
  }

  public deleteCurso(id: number): boolean {
    const hasStudents = this.data.estudiantes.some(e => e.id_curso === id);
    if (hasStudents) {
      throw new Error('No se puede eliminar el curso porque tiene estudiantes asignados. Reasigne o dé de baja los estudiantes primero.');
    }
    const idx = this.data.cursos.findIndex(c => c.id_curso === id);
    if (idx === -1) return false;
    this.data.cursos.splice(idx, 1);
    this.persist();
    return true;
  }

  // ================= ESTUDIANTES =================
  public getEstudiantes(filters?: {
    id_curso?: number;
    anio?: number;
    division?: string;
    search?: string;
    estado?: boolean;
  }): (Estudiante & { curso_descripcion: string; anio: number; division: string; turno: string })[] {
    let result = this.data.estudiantes.map(e => {
      const curso = this.data.cursos.find(c => c.id_curso === e.id_curso);
      return {
        ...e,
        curso_descripcion: curso ? `${curso.anio}° "${curso.division}" - ${curso.turno}` : 'Sin curso',
        anio: curso ? curso.anio : 0,
        division: curso ? curso.division : '',
        turno: curso ? curso.turno : ''
      };
    });

    if (filters) {
      if (filters.id_curso !== undefined) {
        result = result.filter(e => e.id_curso === Number(filters.id_curso));
      }
      if (filters.anio !== undefined) {
        result = result.filter(e => e.anio === Number(filters.anio));
      }
      if (filters.division) {
        result = result.filter(e => e.division.toUpperCase() === filters.division?.toUpperCase());
      }
      if (filters.estado !== undefined) {
        result = result.filter(e => e.estado === filters.estado);
      }
      if (filters.search) {
        const query = filters.search.toLowerCase().trim();
        result = result.filter(
          e => e.dni.includes(query) ||
               e.apellido.toLowerCase().includes(query) ||
               e.nombre.toLowerCase().includes(query)
        );
      }
    }

    return result.sort((a, b) => a.apellido.localeCompare(b.apellido) || a.nombre.localeCompare(b.nombre));
  }

  public getEstudianteById(id: number): (Estudiante & { curso?: Curso }) | undefined {
    const est = this.data.estudiantes.find(e => e.id_estudiante === id);
    if (!est) return undefined;
    const curso = this.data.cursos.find(c => c.id_curso === est.id_curso);
    return { ...est, curso };
  }

  public createEstudiante(data: Omit<Estudiante, 'id_estudiante'>): Estudiante {
    // Validar DNI único
    const dniClean = data.dni.replace(/\D/g, '');
    if (!dniClean || dniClean.length < 7) {
      throw new Error('El DNI debe tener al menos 7 dígitos numéricos.');
    }
    const existing = this.data.estudiantes.find(e => e.dni.replace(/\D/g, '') === dniClean);
    if (existing) {
      throw new Error(`Ya existe un estudiante registrado con el DNI ${data.dni}.`);
    }

    // Validar curso existente (FK)
    const curso = this.data.cursos.find(c => c.id_curso === Number(data.id_curso));
    if (!curso) {
      throw new Error('El curso seleccionado no es válido.');
    }

    const nextId = this.data.estudiantes.reduce((max, e) => Math.max(max, e.id_estudiante), 0) + 1;
    const newEstudiante: Estudiante = {
      id_estudiante: nextId,
      dni: data.dni.trim(),
      apellido: data.apellido.trim(),
      nombre: data.nombre.trim(),
      id_curso: Number(data.id_curso),
      estado: data.estado !== undefined ? Boolean(data.estado) : true,
      telefono_tutor: data.telefono_tutor?.trim() || undefined,
      email_tutor: data.email_tutor?.trim() || undefined
    };

    this.data.estudiantes.push(newEstudiante);
    this.persist();
    return newEstudiante;
  }

  public updateEstudiante(id: number, data: Partial<Omit<Estudiante, 'id_estudiante'>>): Estudiante {
    const est = this.data.estudiantes.find(e => e.id_estudiante === id);
    if (!est) throw new Error('Estudiante no encontrado');

    if (data.dni !== undefined) {
      const dniClean = data.dni.replace(/\D/g, '');
      const conflict = this.data.estudiantes.find(e => e.id_estudiante !== id && e.dni.replace(/\D/g, '') === dniClean);
      if (conflict) {
        throw new Error(`El DNI ${data.dni} ya pertenece a otro estudiante.`);
      }
      est.dni = data.dni.trim();
    }

    if (data.apellido !== undefined) est.apellido = data.apellido.trim();
    if (data.nombre !== undefined) est.nombre = data.nombre.trim();
    if (data.id_curso !== undefined) {
      const curso = this.data.cursos.find(c => c.id_curso === Number(data.id_curso));
      if (!curso) throw new Error('El curso especificado no existe.');
      est.id_curso = Number(data.id_curso);
    }
    if (data.estado !== undefined) est.estado = Boolean(data.estado);
    if (data.telefono_tutor !== undefined) est.telefono_tutor = data.telefono_tutor.trim();
    if (data.email_tutor !== undefined) est.email_tutor = data.email_tutor.trim();

    this.persist();
    return est;
  }

  public deleteEstudiante(id: number, hardDelete: boolean = false): boolean {
    const idx = this.data.estudiantes.findIndex(e => e.id_estudiante === id);
    if (idx === -1) return false;

    if (hardDelete) {
      // Eliminar registros de asistencia asociados en cascada
      this.data.asistencias = this.data.asistencias.filter(a => a.id_estudiante !== id);
      this.data.estudiantes.splice(idx, 1);
    } else {
      // Baja lógica recomendada
      this.data.estudiantes[idx].estado = false;
    }

    this.persist();
    return true;
  }

  // ================= ASISTENCIAS =================
  public getAsistenciasPorCursoYFecha(id_curso: number, fecha: string, jornada: 'Mañana' | 'Tarde') {
    const estudiantes = this.getEstudiantes({ id_curso, estado: true });
    const asistencias = this.data.asistencias.filter(
      a => a.fecha === fecha && a.jornada === jornada
    );

    const sheet = estudiantes.map(est => {
      const reg = asistencias.find(a => a.id_estudiante === est.id_estudiante);
      return {
        estudiante: est,
        asistencia: reg || null
      };
    });

    const counts = {
      total: estudiantes.length,
      registrados: sheet.filter(s => s.asistencia !== null).length,
      presentes: sheet.filter(s => s.asistencia?.estado === 'P').length,
      ausentes: sheet.filter(s => s.asistencia?.estado === 'A').length,
      tardanzas: sheet.filter(s => s.asistencia?.estado === 'T').length,
      ausentes_justificados: sheet.filter(s => s.asistencia?.estado === 'AJ').length
    };

    return {
      id_curso,
      fecha,
      jornada,
      counts,
      alumnos: sheet
    };
  }

  /**
   * Guarda lote de asistencias para un curso, fecha y jornada.
   * Regla de oro requerida: "No se deberá permitir registrar dos veces la asistencia del mismo estudiante para la misma fecha y jornada."
   * Si allowUpdate es false y ya existen registros para esa fecha y jornada, rechaza para evitar duplicados accidentales.
   * Si allowUpdate es true, actualiza el registro existente de forma segura (UPSERT).
   */
  public saveBatchAsistencias(params: {
    id_curso: number;
    fecha: string;
    jornada: 'Mañana' | 'Tarde';
    id_usuario: number;
    allowUpdate?: boolean;
    registros: {
      id_estudiante: number;
      estado: 'P' | 'A' | 'T' | 'AJ';
      observacion?: string;
    }[];
  }) {
    const { id_curso, fecha, jornada, id_usuario, allowUpdate = false, registros } = params;

    // Verificar si ya existen registros
    const existing = this.data.asistencias.filter(
      a => a.fecha === fecha && a.jornada === jornada && registros.some(r => r.id_estudiante === a.id_estudiante)
    );

    if (existing.length > 0 && !allowUpdate) {
      throw new Error(
        `Ya existe un registro de asistencia para la fecha ${fecha} y jornada ${jornada} en este curso. Habilite el modo de edición para modificarlo.`
      );
    }

    let nextId = this.data.asistencias.reduce((max, a) => Math.max(max, a.id_asistencia), 0) + 1;
    const timestamp = new Date().toISOString();

    for (const item of registros) {
      // Validar que el estudiante pertenezca al curso
      const est = this.data.estudiantes.find(e => e.id_estudiante === item.id_estudiante);
      if (!est) continue;

      const existingIndex = this.data.asistencias.findIndex(
        a => a.id_estudiante === item.id_estudiante && a.fecha === fecha && a.jornada === jornada
      );

      if (existingIndex !== -1) {
        // Modificación de registro existente
        this.data.asistencias[existingIndex].estado = item.estado;
        this.data.asistencias[existingIndex].observacion = item.observacion || undefined;
        this.data.asistencias[existingIndex].id_usuario = id_usuario;
      } else {
        // Inserción con UNIQUE garantizado
        this.data.asistencias.push({
          id_asistencia: nextId++,
          id_estudiante: item.id_estudiante,
          fecha,
          estado: item.estado,
          observacion: item.observacion || undefined,
          id_usuario,
          jornada,
          creado_el: timestamp
        });
      }
    }

    this.persist();
    return this.getAsistenciasPorCursoYFecha(id_curso, fecha, jornada);
  }

  // ================= CONSULTAS Y HISTORIAL =================
  public getHistorialEstudiante(id_estudiante: number) {
    const estudiante = this.getEstudianteById(id_estudiante);
    if (!estudiante) throw new Error('Estudiante no encontrado');

    const asistencias = this.data.asistencias
      .filter(a => a.id_estudiante === id_estudiante)
      .sort((a, b) => b.fecha.localeCompare(a.fecha));

    const total = asistencias.length;
    const presentes = asistencias.filter(a => a.estado === 'P').length;
    const ausentes = asistencias.filter(a => a.estado === 'A').length;
    const tardanzas = asistencias.filter(a => a.estado === 'T').length;
    const ausentes_justificados = asistencias.filter(a => a.estado === 'AJ').length;

    // En sistema escolar técnico: Presente = 100%, Tardanza = 0.5 inasistencia (o según reglamento), Ausente = 1 inasistencia, AJ = justificada
    const porcentajeAsistencia = total > 0 ? Number(((presentes / total) * 100).toFixed(1)) : 100;
    const porcentajeInasistencia = total > 0 ? Number((((ausentes + tardanzas * 0.5) / total) * 100).toFixed(1)) : 0;

    return {
      estudiante,
      total_dias: total,
      presentes,
      ausentes,
      tardanzas,
      ausentes_justificados,
      porcentaje_asistencia: porcentajeAsistencia,
      porcentaje_inasistencia: porcentajeInasistencia,
      historial: asistencias
    };
  }

  public queryAsistencias(filters: {
    id_curso?: number;
    id_estudiante?: number;
    fecha_desde?: string;
    fecha_hasta?: string;
    estado?: string;
  }) {
    let list = [...this.data.asistencias];

    if (filters.id_estudiante) {
      list = list.filter(a => a.id_estudiante === Number(filters.id_estudiante));
    }

    if (filters.id_curso) {
      const studentIdsInCourse = new Set(
        this.data.estudiantes.filter(e => e.id_curso === Number(filters.id_curso)).map(e => e.id_estudiante)
      );
      list = list.filter(a => studentIdsInCourse.has(a.id_estudiante));
    }

    if (filters.fecha_desde) {
      list = list.filter(a => a.fecha >= filters.fecha_desde!);
    }

    if (filters.fecha_hasta) {
      list = list.filter(a => a.fecha <= filters.fecha_hasta!);
    }

    if (filters.estado) {
      list = list.filter(a => a.estado === filters.estado);
    }

    // Attach student & course metadata for UI consumption
    return list.map(a => {
      const est = this.data.estudiantes.find(e => e.id_estudiante === a.id_estudiante);
      const curso = est ? this.data.cursos.find(c => c.id_curso === est.id_curso) : undefined;
      const user = this.data.usuarios.find(u => u.id_usuario === a.id_usuario);
      return {
        ...a,
        estudiante: est ? {
          id_estudiante: est.id_estudiante,
          dni: est.dni,
          apellido: est.apellido,
          nombre: est.nombre
        } : null,
        curso: curso ? {
          id_curso: curso.id_curso,
          descripcion: `${curso.anio}° "${curso.division}" - ${curso.turno}`
        } : null,
        registrado_por: user ? user.nombre_completo : 'Sistema'
      };
    }).sort((a, b) => b.fecha.localeCompare(a.fecha) || (a.estudiante?.apellido || '').localeCompare(b.estudiante?.apellido || ''));
  }

  // ================= ESTADÍSTICAS GLOBALES =================
  public getEstadisticasGlobales() {
    const totalEstudiantesActivos = this.data.estudiantes.filter(e => e.estado).length;
    const totalRegistros = this.data.asistencias.length;

    const totalP = this.data.asistencias.filter(a => a.estado === 'P').length;
    const totalA = this.data.asistencias.filter(a => a.estado === 'A').length;
    const totalT = this.data.asistencias.filter(a => a.estado === 'T').length;
    const totalAJ = this.data.asistencias.filter(a => a.estado === 'AJ').length;

    const porcentajeAsistencia = totalRegistros > 0
      ? Number(((totalP / totalRegistros) * 100).toFixed(1))
      : 100;
    const porcentajeInasistencia = totalRegistros > 0
      ? Number((((totalA + totalAJ) / totalRegistros) * 100).toFixed(1))
      : 0;

    // Comparación entre cursos
    const cursosStats = this.data.cursos.map(curso => {
      const estudiantesCurso = this.data.estudiantes.filter(e => e.id_curso === curso.id_curso && e.estado);
      const studentIds = new Set(estudiantesCurso.map(e => e.id_estudiante));
      const asistCurso = this.data.asistencias.filter(a => studentIds.has(a.id_estudiante));

      const cTotal = asistCurso.length;
      const cP = asistCurso.filter(a => a.estado === 'P').length;
      const cA = asistCurso.filter(a => a.estado === 'A').length;
      const cT = asistCurso.filter(a => a.estado === 'T').length;
      const cAJ = asistCurso.filter(a => a.estado === 'AJ').length;

      const pAsist = cTotal > 0 ? Number(((cP / cTotal) * 100).toFixed(1)) : 100;

      return {
        id_curso: curso.id_curso,
        anio: curso.anio,
        division: curso.division,
        turno: curso.turno,
        nombre: `${curso.anio}° "${curso.division}" (${curso.turno})`,
        estudiantes: estudiantesCurso.length,
        total_asistencias: cTotal,
        presentes: cP,
        ausentes: cA,
        tardanzas: cT,
        ausentes_justificados: cAJ,
        porcentaje_asistencia: pAsist
      };
    });

    // Estudiantes con mayor cantidad de ausencias (alertas de seguimiento)
    const ausenciasPorEstudiante = this.data.estudiantes.filter(e => e.estado).map(est => {
      const records = this.data.asistencias.filter(a => a.id_estudiante === est.id_estudiante);
      const totalDays = records.length;
      const ausenciasInjustificadas = records.filter(a => a.estado === 'A').length;
      const ausenciasJustificadas = records.filter(a => a.estado === 'AJ').length;
      const tardanzas = records.filter(a => a.estado === 'T').length;
      const curso = this.data.cursos.find(c => c.id_curso === est.id_curso);

      // Inasistencias computadas totales (Reglamento: 1 A = 1 inasistencia, 1 T = 0.5 inasistencia)
      const inasistenciasComputadas = ausenciasInjustificadas + ausenciasJustificadas + (tardanzas * 0.5);

      return {
        id_estudiante: est.id_estudiante,
        dni: est.dni,
        nombre_completo: `${est.apellido}, ${est.nombre}`,
        curso: curso ? `${curso.anio}° "${curso.division}"` : 'S/D',
        total_dias: totalDays,
        ausencias_injustificadas: ausenciasInjustificadas,
        ausencias_justificadas: ausenciasJustificadas,
        tardanzas,
        inasistencias_computadas: Number(inasistenciasComputadas.toFixed(1)),
        alerta_reincorporacion: inasistenciasComputadas >= 15 || (totalDays > 0 && (inasistenciasComputadas / totalDays) > 0.25)
      };
    }).sort((a, b) => b.inasistencias_computadas - a.inasistencias_computadas).slice(0, 8);

    // Fechas recientes con desglose diario
    const fechasUnicas = Array.from(new Set(this.data.asistencias.map(a => a.fecha))).sort().slice(-10);
    const tendenciaDiaria = fechasUnicas.map(f => {
      const delDia = this.data.asistencias.filter(a => a.fecha === f);
      const tot = delDia.length;
      const p = delDia.filter(a => a.estado === 'P').length;
      const a = delDia.filter(a => a.estado === 'A').length;
      const t = delDia.filter(a => a.estado === 'T').length;
      const aj = delDia.filter(a => a.estado === 'AJ').length;
      return {
        fecha: f,
        total: tot,
        presentes: p,
        ausentes: a,
        tardanzas: t,
        ausentes_justificados: aj,
        tasa_asistencia: tot > 0 ? Number(((p / tot) * 100).toFixed(1)) : 0
      };
    });

    return {
      resumen: {
        total_estudiantes: totalEstudiantesActivos,
        total_cursos: this.data.cursos.length,
        total_registros: totalRegistros,
        presentes: totalP,
        ausentes: totalA,
        tardanzas: totalT,
        ausentes_justificados: totalAJ,
        porcentaje_asistencia: porcentajeAsistencia,
        porcentaje_inasistencia: porcentajeInasistencia
      },
      cursos: cursosStats,
      top_ausencias: ausenciasPorEstudiante,
      tendencia_diaria: tendenciaDiaria
    };
  }
}

export const db = new RelationalDatabase();
