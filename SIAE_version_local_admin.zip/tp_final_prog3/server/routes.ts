import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { db } from './db.js';

export const apiRouter = Router();

// Middleware simple para simular autenticación basada en header o mock token
const getUserFromReq = (req: Request) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const username = authHeader.substring(7);
    return db.getUsuarioByUsername(username);
  }
  return undefined;
};

// ================= AUTENTICACIÓN =================
apiRouter.post('/auth/login', (req: Request, res: Response): void => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      res.status(400).json({ error: 'Debe ingresar nombre de usuario y contraseña.' });
      return;
    }

    const usuario = db.getUsuarioByUsername(username);
    if (!usuario) {
      res.status(401).json({ error: 'Credenciales inválidas. Usuario no registrado.' });
      return;
    }

    const passwordValida = bcrypt.compareSync(password, usuario.password_hash);
    if (!passwordValida) {
      res.status(401).json({ error: 'Credenciales inválidas. Contraseña incorrecta.' });
      return;
    }

    // Token representativo (username)
    const token = usuario.nombre_usuario;
    const { password_hash, ...perfil } = usuario;

    res.json({
      token,
      usuario: perfil
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Error en el servidor durante login.' });
  }
});

apiRouter.get('/auth/me', (req: Request, res: Response): void => {
  const usuario = getUserFromReq(req);
  if (!usuario) {
    res.status(401).json({ error: 'No autenticado.' });
    return;
  }
  const { password_hash, ...perfil } = usuario;
  res.json({ usuario: perfil });
});

apiRouter.post('/auth/logout', (_req: Request, res: Response): void => {
  res.json({ message: 'Sesión cerrada correctamente.' });
});

// ================= GESTIÓN DE CURSOS =================
apiRouter.get('/cursos', (_req: Request, res: Response): void => {
  try {
    const cursos = db.getCursos();
    res.json(cursos);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

apiRouter.post('/cursos', (req: Request, res: Response): void => {
  try {
    const { anio, division, turno, especialidad } = req.body;
    if (!anio || !division || !turno) {
      res.status(400).json({ error: 'Año, división y turno son campos obligatorios.' });
      return;
    }

    const nuevoCurso = db.createCurso({
      anio: Number(anio),
      division,
      turno,
      especialidad
    });

    res.status(201).json(nuevoCurso);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

apiRouter.put('/cursos/:id', (req: Request, res: Response): void => {
  try {
    const id = Number(req.params.id);
    const updated = db.updateCurso(id, req.body);
    res.json(updated);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

apiRouter.delete('/cursos/:id', (req: Request, res: Response): void => {
  try {
    const id = Number(req.params.id);
    const deleted = db.deleteCurso(id);
    if (!deleted) {
      res.status(404).json({ error: 'Curso no encontrado.' });
      return;
    }
    res.json({ message: 'Curso eliminado exitosamente.' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// ================= GESTIÓN DE ESTUDIANTES =================
apiRouter.get('/estudiantes', (req: Request, res: Response): void => {
  try {
    const { id_curso, anio, division, search, estado } = req.query;
    const filters: any = {};
    if (id_curso) filters.id_curso = Number(id_curso);
    if (anio) filters.anio = Number(anio);
    if (division) filters.division = String(division);
    if (search) filters.search = String(search);
    if (estado !== undefined) filters.estado = estado === 'true';

    const estudiantes = db.getEstudiantes(filters);
    res.json(estudiantes);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

apiRouter.get('/estudiantes/:id', (req: Request, res: Response): void => {
  try {
    const id = Number(req.params.id);
    const estudiante = db.getEstudianteById(id);
    if (!estudiante) {
      res.status(404).json({ error: 'Estudiante no encontrado.' });
      return;
    }
    res.json(estudiante);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

apiRouter.post('/estudiantes', (req: Request, res: Response): void => {
  try {
    const { dni, apellido, nombre, id_curso, estado, telefono_tutor, email_tutor } = req.body;
    if (!dni || !apellido || !nombre || !id_curso) {
      res.status(400).json({ error: 'DNI, Apellido, Nombre y Curso son obligatorios.' });
      return;
    }

    const nuevo = db.createEstudiante({
      dni,
      apellido,
      nombre,
      id_curso: Number(id_curso),
      estado: estado !== undefined ? Boolean(estado) : true,
      telefono_tutor,
      email_tutor
    });

    res.status(201).json(nuevo);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

apiRouter.put('/estudiantes/:id', (req: Request, res: Response): void => {
  try {
    const id = Number(req.params.id);
    const updated = db.updateEstudiante(id, req.body);
    res.json(updated);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

apiRouter.delete('/estudiantes/:id', (req: Request, res: Response): void => {
  try {
    const id = Number(req.params.id);
    const hardDelete = req.query.hard === 'true';
    const deleted = db.deleteEstudiante(id, hardDelete);
    if (!deleted) {
      res.status(404).json({ error: 'Estudiante no encontrado.' });
      return;
    }
    res.json({ message: hardDelete ? 'Estudiante eliminado definitivamente.' : 'Estudiante dado de baja lógicamente.' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// ================= REGISTRO DE ASISTENCIA =================
// Obtiene planilla para tomar asistencia
apiRouter.get('/asistencias/sheet', (req: Request, res: Response): void => {
  try {
    const { id_curso, fecha, jornada } = req.query;
    if (!id_curso || !fecha) {
      res.status(400).json({ error: 'Debe especificar id_curso y fecha.' });
      return;
    }

    const j = (jornada === 'Tarde' ? 'Tarde' : 'Mañana') as 'Mañana' | 'Tarde';
    const data = db.getAsistenciasPorCursoYFecha(Number(id_curso), String(fecha), j);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Guarda lote de asistencia con restricción UNIQUE sobre estudiante, fecha y jornada
apiRouter.post('/asistencias/batch', (req: Request, res: Response): void => {
  try {
    const { id_curso, fecha, jornada, allowUpdate, registros } = req.body;
    if (!id_curso || !fecha || !registros || !Array.isArray(registros)) {
      res.status(400).json({ error: 'Datos de asistencia incompletos.' });
      return;
    }

    const user = getUserFromReq(req) || { id_usuario: 1 };
    const j = (jornada === 'Tarde' ? 'Tarde' : 'Mañana') as 'Mañana' | 'Tarde';

    const result = db.saveBatchAsistencias({
      id_curso: Number(id_curso),
      fecha: String(fecha),
      jornada: j,
      id_usuario: user.id_usuario,
      allowUpdate: Boolean(allowUpdate),
      registros
    });

    res.json({
      message: 'Asistencia registrada correctamente en la base de datos.',
      data: result
    });
  } catch (error: any) {
    // Si es conflicto de duplicado, enviamos 409
    const isConflict = error.message?.includes('Ya existe un registro');
    res.status(isConflict ? 409 : 400).json({ error: error.message });
  }
});

// ================= CONSULTA Y HISTORIAL =================
apiRouter.get('/asistencias/query', (req: Request, res: Response): void => {
  try {
    const { id_curso, id_estudiante, fecha_desde, fecha_hasta, estado } = req.query;
    const records = db.queryAsistencias({
      id_curso: id_curso ? Number(id_curso) : undefined,
      id_estudiante: id_estudiante ? Number(id_estudiante) : undefined,
      fecha_desde: fecha_desde ? String(fecha_desde) : undefined,
      fecha_hasta: fecha_hasta ? String(fecha_hasta) : undefined,
      estado: estado ? String(estado) : undefined
    });
    res.json(records);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

apiRouter.get('/asistencias/estudiante/:id', (req: Request, res: Response): void => {
  try {
    const id = Number(req.params.id);
    const historial = db.getHistorialEstudiante(id);
    res.json(historial);
  } catch (error: any) {
    res.status(404).json({ error: error.message });
  }
});

// ================= ESTADÍSTICAS GLOBALES =================
apiRouter.get('/estadisticas', (_req: Request, res: Response): void => {
  try {
    const stats = db.getEstadisticasGlobales();
    res.json(stats);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ================= EXPORTACIÓN CSV =================
apiRouter.get('/export/csv', (req: Request, res: Response): void => {
  try {
    const { id_curso, fecha_desde, fecha_hasta } = req.query;
    const records = db.queryAsistencias({
      id_curso: id_curso ? Number(id_curso) : undefined,
      fecha_desde: fecha_desde ? String(fecha_desde) : undefined,
      fecha_hasta: fecha_hasta ? String(fecha_hasta) : undefined
    });

    const headers = ['Fecha', 'Jornada', 'Curso', 'DNI', 'Apellido y Nombre', 'Estado', 'Significado', 'Observacion', 'Registrado Por'];
    const estadoLabels: Record<string, string> = {
      P: 'Presente',
      A: 'Ausente',
      T: 'Tardanza',
      AJ: 'Ausente Justificado'
    };

    const rows = records.map(r => [
      r.fecha,
      r.jornada,
      `"${r.curso?.descripcion || ''}"`,
      r.estudiante?.dni || '',
      `"${r.estudiante?.apellido || ''}, ${r.estudiante?.nombre || ''}"`,
      r.estado,
      estadoLabels[r.estado] || r.estado,
      `"${(r.observacion || '').replace(/"/g, '""')}"`,
      `"${r.registrado_por || ''}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(row => row.join(','))].join('\r\n');

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename=asistencias_siae_${Date.now()}.csv`);
    res.status(200).send(csvContent);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ================= RESET SEED =================
apiRouter.post('/seed/reset', (_req: Request, res: Response): void => {
  try {
    db.seedInitialData(true);
    res.json({ message: 'Base de datos restaurada al conjunto de prueba oficial.' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});
