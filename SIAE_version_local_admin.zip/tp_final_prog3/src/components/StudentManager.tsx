import React, { useState, useEffect } from 'react';
import { Course, Student, StudentHistoryResponse } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import {
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  X,
  History,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Phone,
  UserCheck,
  UserX,
  Calendar
} from 'lucide-react';

interface StudentManagerProps {
  courses: Course[];
  onSelectStudentForAttendanceHistory?: (studentId: number) => void;
}

export const StudentManager: React.FC<StudentManagerProps> = ({ courses }) => {
  const { canEditStudents } = useAuth();

  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [filterCourseId, setFilterCourseId] = useState<string>('all');
  const [filterEstado, setFilterEstado] = useState<string>('true');

  // Modal create/edit
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [formDni, setFormDni] = useState<string>('');
  const [formApellido, setFormApellido] = useState<string>('');
  const [formNombre, setFormNombre] = useState<string>('');
  const [formCursoId, setFormCursoId] = useState<number>(courses[0]?.id_curso || 1);
  const [formEstado, setFormEstado] = useState<boolean>(true);
  const [formTelefono, setFormTelefono] = useState<string>('');
  const [formEmail, setFormEmail] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Student history modal
  const [historyModalOpen, setHistoryModalOpen] = useState<boolean>(false);
  const [selectedStudentHistory, setSelectedStudentHistory] = useState<StudentHistoryResponse | null>(null);
  const [loadingHistory, setLoadingHistory] = useState<boolean>(false);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const params: any = {};
      if (search.trim()) params.search = search.trim();
      if (filterCourseId !== 'all') params.id_curso = Number(filterCourseId);
      if (filterEstado !== 'all') params.estado = filterEstado === 'true';

      const data = await api.getEstudiantes(params);
      setStudents(data);
    } catch (err) {
      console.error('Error fetching students:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, [search, filterCourseId, filterEstado]);

  const openCreateModal = () => {
    setEditingStudent(null);
    setFormDni('');
    setFormApellido('');
    setFormNombre('');
    setFormCursoId(courses[0]?.id_curso || 1);
    setFormEstado(true);
    setFormTelefono('');
    setFormEmail('');
    setFormError(null);
    setModalOpen(true);
  };

  const openEditModal = (st: Student) => {
    setEditingStudent(st);
    setFormDni(st.dni);
    setFormApellido(st.apellido);
    setFormNombre(st.nombre);
    setFormCursoId(st.id_curso);
    setFormEstado(st.estado);
    setFormTelefono(st.telefono_tutor || '');
    setFormEmail(st.email_tutor || '');
    setFormError(null);
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setFormError(null);

    try {
      if (editingStudent) {
        await api.updateEstudiante(editingStudent.id_estudiante, {
          dni: formDni.trim(),
          apellido: formApellido.trim(),
          nombre: formNombre.trim(),
          id_curso: formCursoId,
          estado: formEstado,
          telefono_tutor: formTelefono.trim() || undefined,
          email_tutor: formEmail.trim() || undefined
        });
      } else {
        await api.createEstudiante({
          dni: formDni.trim(),
          apellido: formApellido.trim(),
          nombre: formNombre.trim(),
          id_curso: formCursoId,
          estado: formEstado,
          telefono_tutor: formTelefono.trim() || undefined,
          email_tutor: formEmail.trim() || undefined
        });
      }
      setModalOpen(false);
      fetchStudents();
    } catch (err: any) {
      setFormError(err.message || 'Error al guardar el estudiante.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleEstado = async (st: Student) => {
    try {
      await api.updateEstudiante(st.id_estudiante, { estado: !st.estado });
      fetchStudents();
    } catch (err: any) {
      alert(err.message || 'Error al modificar estado del estudiante.');
    }
  };

  const handleDelete = async (st: Student) => {
    if (!window.confirm(`¿Desea eliminar a ${st.apellido}, ${st.nombre} del sistema? Se realizará baja lógica.`)) {
      return;
    }
    try {
      await api.deleteEstudiante(st.id_estudiante, false);
      fetchStudents();
    } catch (err: any) {
      alert(err.message || 'Error al eliminar el estudiante.');
    }
  };

  const handleOpenHistory = async (id: number) => {
    setLoadingHistory(true);
    setHistoryModalOpen(true);
    try {
      const data = await api.getStudentHistory(id);
      setSelectedStudentHistory(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingHistory(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Gestión de Estudiantes
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Registro, modificación, búsqueda por DNI o apellido y seguimiento individual
          </p>
        </div>

        {canEditStudents && (
          <button
            type="button"
            onClick={openCreateModal}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            Inscribir Estudiante
          </button>
        )}
      </div>

      {/* Filters & Search Toolbar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search bar */}
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar por DNI, apellido o nombre..."
              className="w-full h-9.5 pl-9 pr-3 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Filter Course */}
          <div className="md:col-span-4">
            <select
              value={filterCourseId}
              onChange={(e) => setFilterCourseId(e.target.value)}
              aria-label="Filtrar por curso y división"
              className="w-full h-9.5 px-3 text-xs bg-white border border-slate-300 rounded-lg text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">Todos los Cursos y Divisiones</option>
              {courses.map(c => (
                <option key={c.id_curso} value={c.id_curso}>
                  {c.anio}.º "{c.division}" · Turno {c.turno}
                </option>
              ))}
            </select>
          </div>

          {/* Filter Status */}
          <div className="md:col-span-3">
            <select
              value={filterEstado}
              onChange={(e) => setFilterEstado(e.target.value)}
              aria-label="Filtrar por estado del alumno"
              className="w-full h-9.5 px-3 text-xs bg-white border border-slate-300 rounded-lg text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="true">Solo Activos (Regulares)</option>
              <option value="false">Solo Inactivos (Bajas)</option>
              <option value="all">Todos los Estados</option>
            </select>
          </div>
        </div>

        {/* Quick result count */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>
            Mostrando <strong>{students.length}</strong> estudiantes
          </span>
          {search && (
            <button
              onClick={() => setSearch('')}
              className="text-indigo-600 hover:underline text-xs"
            >
              Limpiar búsqueda
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            Cargando nómina de estudiantes...
          </div>
        ) : students.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <p className="font-medium text-slate-700">No se encontraron estudiantes.</p>
            <p className="text-xs text-slate-400 mt-1">
              {search ? 'Pruebe con otro término de búsqueda o limpie los filtros.' : 'Utilice el botón "Inscribir Estudiante" para agregar alumnos al sistema.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4 w-12 text-center">#</th>
                  <th className="py-3 px-4 w-28">DNI</th>
                  <th className="py-3 px-4 min-w-[200px]">Apellido y Nombre</th>
                  <th className="py-3 px-4 min-w-[150px]">Curso Asignado</th>
                  <th className="py-3 px-4 min-w-[160px]">Contacto Tutor</th>
                  <th className="py-3 px-4 w-28 text-center">Estado</th>
                  <th className="py-3 px-4 w-32 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {students.map((st, idx) => (
                  <tr key={st.id_estudiante} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 text-center font-mono text-slate-400">{idx + 1}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-700 font-medium">
                      {st.dni}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900 text-sm">
                        {st.apellido}, {st.nombre}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800">
                        {st.curso_descripcion}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {st.telefono_tutor ? (
                        <div className="flex items-center gap-1.5 font-mono text-[11px]">
                          <Phone className="w-3 h-3 text-slate-400" />
                          {st.telefono_tutor}
                        </div>
                      ) : (
                        <span className="text-slate-400">Sin registrar</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        type="button"
                        onClick={() => canEditStudents && handleToggleEstado(st)}
                        disabled={!canEditStudents}
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                          st.estado
                            ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                            : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                        title={canEditStudents ? 'Clic para alternar estado' : undefined}
                      >
                        {st.estado ? <UserCheck className="w-3 h-3" /> : <UserX className="w-3 h-3" />}
                        {st.estado ? 'Activo' : 'Inactivo'}
                      </button>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenHistory(st.id_estudiante)}
                          className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors"
                          title="Ver historial de asistencias"
                        >
                          <History className="w-4 h-4" />
                        </button>
                        {canEditStudents && (
                          <>
                            <button
                              type="button"
                              onClick={() => openEditModal(st)}
                              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors"
                              title="Editar datos"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDelete(st)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                              title="Dar de baja"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal: Inscribir / Editar Estudiante */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="font-semibold text-slate-900 text-sm">
                {editingStudent ? 'Modificar Estudiante' : 'Inscripción de Nuevo Estudiante'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* DNI */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  DNI (Documento Nacional de Identidad) *
                </label>
                <input
                  type="text"
                  required
                  value={formDni}
                  onChange={(e) => setFormDni(e.target.value.replace(/\D/g, ''))}
                  placeholder="Ej: 48912345"
                  className="w-full text-xs h-9 px-3 border border-slate-300 rounded-lg font-mono tabular-nums focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              {/* Apellido */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Apellido(s) *
                </label>
                <input
                  type="text"
                  required
                  value={formApellido}
                  onChange={(e) => setFormApellido(e.target.value)}
                  placeholder="Ej: Gómez"
                  className="w-full text-xs h-9 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              {/* Nombre */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nombre(s) *
                </label>
                <input
                  type="text"
                  required
                  value={formNombre}
                  onChange={(e) => setFormNombre(e.target.value)}
                  placeholder="Ej: Lucas Valentín"
                  className="w-full text-xs h-9 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              {/* Curso */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Curso Asignado (Año y División) *
                </label>
                <select
                  value={formCursoId}
                  onChange={(e) => setFormCursoId(Number(e.target.value))}
                  className="w-full text-xs h-9 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {courses.map(c => (
                    <option key={c.id_curso} value={c.id_curso}>
                      {c.anio}.º "{c.division}" · Turno {c.turno} ({c.especialidad || 'Ciclo Básico'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Teléfono Tutor */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Teléfono de Contacto (Padre / Tutor)
                </label>
                <input
                  type="tel"
                  value={formTelefono}
                  onChange={(e) => setFormTelefono(e.target.value)}
                  placeholder="Ej: 11-4567-8910"
                  className="w-full text-xs h-9 px-3 border border-slate-300 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              {/* Estado */}
              <div className="pt-1">
                <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-700">
                  <input
                    type="checkbox"
                    checked={formEstado}
                    onChange={(e) => setFormEstado(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 border-slate-300 focus:ring-indigo-500"
                  />
                  <span>Estudiante Activo (Matrícula regular)</span>
                </label>
              </div>

              {/* Buttons */}
              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 border border-slate-200 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm disabled:opacity-50"
                >
                  {submitting ? 'Guardando...' : editingStudent ? 'Guardar Cambios' : 'Registrar Estudiante'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Historial Individual del Estudiante */}
      {historyModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-slate-900 text-sm">
                  Historial de Asistencia Individual
                </h3>
                <p className="text-xs text-slate-500">
                  {selectedStudentHistory?.estudiante.apellido}, {selectedStudentHistory?.estudiante.nombre} (DNI: {selectedStudentHistory?.estudiante.dni})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setHistoryModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto flex-1 space-y-4">
              {loadingHistory ? (
                <div className="py-12 text-center text-xs text-slate-400">
                  Cargando legajo de asistencia...
                </div>
              ) : selectedStudentHistory ? (
                <>
                  {/* Summary Metric Chips */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-center">
                      <span className="text-[11px] text-slate-500 block">Días Registrados</span>
                      <span className="text-xl font-bold text-slate-900 font-mono tabular-nums">
                        {selectedStudentHistory.total_dias}
                      </span>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-center">
                      <span className="text-[11px] text-emerald-700 block">Tasa Asistencia</span>
                      <span className="text-xl font-bold text-emerald-800 font-mono tabular-nums">
                        {selectedStudentHistory.porcentaje_asistencia}%
                      </span>
                    </div>
                    <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-center">
                      <span className="text-[11px] text-rose-700 block">Inasistencias</span>
                      <span className="text-xl font-bold text-rose-800 font-mono tabular-nums">
                        {selectedStudentHistory.ausentes}
                      </span>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-center">
                      <span className="text-[11px] text-amber-700 block">Tardanzas</span>
                      <span className="text-xl font-bold text-amber-800 font-mono tabular-nums">
                        {selectedStudentHistory.tardanzas}
                      </span>
                    </div>
                  </div>

                  {/* Attendance Log List */}
                  <div>
                    <h4 className="text-xs font-semibold text-slate-800 mb-2">
                      Detalle de Asistencias Registradas
                    </h4>
                    {selectedStudentHistory.historial.length === 0 ? (
                      <p className="text-xs text-slate-400 py-4">No hay asistencias registradas aún para este estudiante.</p>
                    ) : (
                      <div className="border border-slate-200 rounded-lg overflow-hidden">
                        <table className="w-full text-left text-xs">
                          <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-slate-500">
                              <th className="py-2 px-3">Fecha</th>
                              <th className="py-2 px-3">Jornada</th>
                              <th className="py-2 px-3">Estado</th>
                              <th className="py-2 px-3">Observación</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {selectedStudentHistory.historial.map((rec) => {
                              const badgeClass = {
                                P: 'bg-emerald-50 text-emerald-700 border-emerald-200',
                                A: 'bg-rose-50 text-rose-700 border-rose-200',
                                T: 'bg-amber-50 text-amber-700 border-amber-200',
                                AJ: 'bg-sky-50 text-sky-700 border-sky-200'
                              }[rec.estado];

                              const label = {
                                P: 'Presente (P)',
                                A: 'Ausente (A)',
                                T: 'Tardanza (T)',
                                AJ: 'Ausente Justificado (AJ)'
                              }[rec.estado];

                              return (
                                <tr key={rec.id_asistencia} className="hover:bg-slate-50">
                                  <td className="py-2 px-3 font-mono tabular-nums text-slate-800">{rec.fecha}</td>
                                  <td className="py-2 px-3 text-slate-600">{rec.jornada}</td>
                                  <td className="py-2 px-3">
                                    <span className={`inline-block px-2 py-0.5 border rounded text-[11px] font-semibold ${badgeClass}`}>
                                      {label}
                                    </span>
                                  </td>
                                  <td className="py-2 px-3 text-slate-600">
                                    {rec.observacion || <span className="text-slate-400 italic">Sin observaciones</span>}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </>
              ) : null}
            </div>

            <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex justify-end">
              <button
                type="button"
                onClick={() => setHistoryModalOpen(false)}
                className="px-4 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
              >
                Cerrar Legajo
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
