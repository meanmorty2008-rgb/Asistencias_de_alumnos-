import React, { useState } from 'react';
import { api } from '../services/api';
import {
  Globe,
  CheckCircle2,
  Copy,
  Terminal,
  Server,
  Smartphone,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  Layers,
  Code
} from 'lucide-react';

export const RenderDeploymentGuide: React.FC = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [healthStatus, setHealthStatus] = useState<any>(null);
  const [testingHealth, setTestingHealth] = useState<boolean>(false);
  const [resettingSeed, setResettingSeed] = useState<boolean>(false);
  const [seedSuccess, setSeedSuccess] = useState<boolean>(false);

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleTestHealth = async () => {
    setTestingHealth(true);
    try {
      const res = await fetch('/health');
      const data = await res.json();
      setHealthStatus({
        status: res.status,
        ok: res.ok,
        data
      });
    } catch (err: any) {
      setHealthStatus({
        status: 'Error',
        ok: false,
        error: err.message
      });
    } finally {
      setTestingHealth(false);
    }
  };

  const handleResetSeed = async () => {
    if (!window.confirm('¿Desea restaurar la base de datos relacional con los datos iniciales de 1.°, 2.° y 3.° año?')) {
      return;
    }
    setResettingSeed(true);
    setSeedSuccess(false);
    try {
      await api.resetSeed();
      setSeedSuccess(true);
      setTimeout(() => setSeedSuccess(false), 3000);
    } catch (err: any) {
      alert(err.message || 'Error al restaurar');
    } finally {
      setResettingSeed(false);
    }
  };

  const steps = [
    {
      title: 'Paso 1: Control de Versiones con Git y GitHub',
      desc: 'Suba el código del proyecto a un nuevo repositorio público o privado en GitHub:',
      cmd: `git init\ngit add .\ngit commit -m "feat: Sistema Web de Asistencia Escolar SIAE - 6to Año"\ngit branch -M main\ngit remote add origin https://github.com/TU_USUARIO/siae-asistencia-escolar.git\ngit push -u origin main`
    },
    {
      title: 'Paso 2: Crear el Web Service en Render.com',
      desc: 'Acceda a https://dashboard.render.com y seleccione "New +" > "Web Service". Conecte su cuenta de GitHub y elija el repositorio recién creado.',
      cmd: null
    },
    {
      title: 'Paso 3: Configurar los Comandos de Render',
      desc: 'En el formulario de configuración de Render, establezca las siguientes directivas exactas:',
      settings: [
        { label: 'Name', value: 'siae-asistencia-escolar' },
        { label: 'Language / Runtime', value: 'Node' },
        { label: 'Branch', value: 'main' },
        { label: 'Build Command', value: 'npm install && npm run build' },
        { label: 'Start Command', value: 'npm start' }
      ]
    },
    {
      title: 'Paso 4: Variables de Entorno en Render (Environment Variables)',
      desc: 'En la sección "Environment" de Render, agregue las siguientes variables:',
      settings: [
        { label: 'NODE_ENV', value: 'production' },
        { label: 'PORT', value: '3000' }
      ]
    },
    {
      title: 'Paso 5: Despliegue con Blueprint render.yaml (Automático)',
      desc: 'El proyecto ya incluye un archivo render.yaml en la raíz. Render puede desplegarlo automáticamente detectando la configuración de servicio web con soporte para SPA y API Express.',
      cmd: `cat render.yaml`
    }
  ];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
          Guía de Publicación en Render y Arquitectura Técnica
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Instrucciones para la publicación en línea del proyecto de 6.º año de Programación
        </p>
      </div>

      {/* Hero Badge card */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-xl p-6 sm:p-7 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="text-xs font-mono text-indigo-300 font-semibold tracking-wider uppercase">
              Objetivo 10 Cumplido · Render Deployment Ready
            </span>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
              Arquitectura Full-Stack Lista para Producción
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              El sistema combina un backend Express con API RESTful, persistencia de base de datos relacional con integridad referencial y restricciones UNIQUE, y frontend React 19 optimizado para computadoras, tablets y teléfonos celulares.
            </p>
          </div>

          <div className="shrink-0 flex flex-col gap-2.5">
            <button
              onClick={handleTestHealth}
              disabled={testingHealth}
              className="px-4 py-2 text-xs font-semibold text-slate-900 bg-white hover:bg-slate-100 rounded-lg shadow-sm transition-colors flex items-center justify-center gap-1.5"
            >
              <Server className="w-4 h-4 text-indigo-600" />
              {testingHealth ? 'Probando...' : 'Comprobar Endpoint /health'}
            </button>

            <button
              onClick={handleResetSeed}
              disabled={resettingSeed}
              className="px-4 py-2 text-xs font-semibold text-indigo-200 hover:text-white bg-indigo-900/60 hover:bg-indigo-900 border border-indigo-700/60 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${resettingSeed ? 'animate-spin' : ''}`} />
              {resettingSeed ? 'Restaurando...' : 'Restaurar BD Inicial'}
            </button>
          </div>
        </div>

        {/* Health status output */}
        {healthStatus && (
          <div className="mt-4 pt-4 border-t border-slate-800 text-xs font-mono">
            <div className="flex items-center gap-2 text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
              <span>Respuesta del servidor ({healthStatus.status}):</span>
            </div>
            <pre className="mt-2 p-3 bg-slate-950/80 rounded border border-slate-800 text-slate-300 overflow-x-auto text-[11px]">
              {JSON.stringify(healthStatus.data || healthStatus.error, null, 2)}
            </pre>
          </div>
        )}

        {seedSuccess && (
          <div className="mt-3 text-xs text-emerald-300 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Base de datos restaurada correctamente.
          </div>
        )}
      </div>

      {/* Deployment Steps */}
      <div className="space-y-4">
        {steps.map((st, i) => (
          <div key={i} className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <h3 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-xs font-mono font-bold flex items-center justify-center">
                {i + 1}
              </span>
              {st.title}
            </h3>
            <p className="text-xs text-slate-600 mt-1.5">
              {st.desc}
            </p>

            {/* If settings list */}
            {st.settings && (
              <div className="mt-3 border border-slate-200 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                    <tr>
                      <th className="py-2 px-3 w-1/3">Parámetro en Render</th>
                      <th className="py-2 px-3">Valor de Configuración</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {st.settings.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2 px-3 text-slate-700 font-sans font-medium">{item.label}</td>
                        <td className="py-2 px-3 text-indigo-700 font-semibold">{item.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* If command block */}
            {st.cmd && (
              <div className="mt-3 relative">
                <pre className="bg-slate-900 text-slate-200 p-3.5 rounded-lg text-xs font-mono overflow-x-auto whitespace-pre leading-relaxed">
                  {st.cmd}
                </pre>
                <button
                  type="button"
                  onClick={() => copyToClipboard(st.cmd!, i)}
                  className="absolute top-2.5 right-2.5 p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                  title="Copiar comando"
                >
                  {copiedIndex === i ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Technical Checklist for Evaluation */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 className="font-semibold text-slate-900 text-sm mb-3 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          Lista de Verificación de Requerimientos de 6.º Año
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 block">Módulo 1: Inicio de Sesión</strong>
              <span className="text-slate-500">Autenticación con usuario/contraseña, roles (Admin/Preceptor/Docente) y hash de contraseñas.</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 block">Módulo 2: Gestión de Cursos</strong>
              <span className="text-slate-500">Cursos de 1.º, 2.º y 3.º año, divisiones A, B, C, turnos y visualización de matrículas.</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 block">Módulo 3: Gestión de Estudiantes</strong>
              <span className="text-slate-500">CRUD completo con DNI único, apellido, nombre, curso, estado activo/inactivo y búsqueda reactiva.</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 block">Módulo 4: Registro de Asistencia</strong>
              <span className="text-slate-500">Estados P, A, T, AJ, observaciones individuales, y restricción UNIQUE (sin registros duplicados).</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 block">Módulo 5: Consultas y Estadísticas</strong>
              <span className="text-slate-500">Reportes por alumno, curso, rango de fechas, top ausencias, gráfico comparativo y exportación PDF/CSV.</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 block">Responsive y Acceso Multi-dispositivo</strong>
              <span className="text-slate-500">Diseñado con Tailwind CSS adaptable a celulares, tablets y computadoras de escritorio.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
