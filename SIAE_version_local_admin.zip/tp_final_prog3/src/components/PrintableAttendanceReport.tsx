import React from 'react';
import { AttendanceRecord } from '../types';
import { Printer, ArrowLeft } from 'lucide-react';

interface PrintableAttendanceReportProps {
  records: AttendanceRecord[];
  title: string;
  onBack: () => void;
}

export const PrintableAttendanceReport: React.FC<PrintableAttendanceReportProps> = ({
  records,
  title,
  onBack
}) => {
  const countP = records.filter(r => r.estado === 'P').length;
  const countA = records.filter(r => r.estado === 'A').length;
  const countT = records.filter(r => r.estado === 'T').length;
  const countAJ = records.filter(r => r.estado === 'AJ').length;
  const total = records.length;
  const pctAsistencia = total > 0 ? ((countP / total) * 100).toFixed(1) : '100';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top action bar (hidden during print) */}
      <div className="no-print bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-xs">
        <button
          type="button"
          onClick={onBack}
          className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Volver al Historial
        </button>

        <div className="flex items-center gap-3">
          <span className="text-xs text-slate-500 hidden sm:inline">
            Presione imprimir para guardar como documento PDF o imprimir en papel A4.
          </span>
          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            Imprimir / Guardar en PDF
          </button>
        </div>
      </div>

      {/* Official Institutional Sheet */}
      <div className="bg-white border border-slate-300 rounded-xl p-8 sm:p-10 shadow-xs max-w-5xl mx-auto print:border-none print:shadow-none print:p-0">
        {/* Institutional Header */}
        <div className="border-b-2 border-slate-900 pb-5 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-slate-100 border border-slate-300 flex items-center justify-center overflow-hidden shrink-0">
              <img
                src="/src/assets/images/school_emblem_logo_1793823363255.jpg"
                alt="Escudo Institucional"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight uppercase">
                Escuela de Educación Secundaria Técnica N.° 6
              </h2>
              <p className="text-xs font-semibold text-slate-700">
                Especialidad en Programación · Formación Técnico Profesional (6.° Año)
              </p>
              <p className="text-[11px] text-slate-500">
                SIAE - Sistema de Información y Administración de Asistencia Escolar
              </p>
            </div>
          </div>

          <div className="text-right text-xs">
            <span className="font-mono text-slate-500 block">Fecha de emisión:</span>
            <span className="font-mono font-semibold text-slate-900 block">
              {new Date().toLocaleDateString('es-AR', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </span>
            <span className="text-[10px] text-slate-400 block mt-1">Cód. Institucional: EEST6-PROG</span>
          </div>
        </div>

        {/* Title of Document */}
        <div className="mb-6 text-center">
          <h1 className="text-base font-bold text-slate-900 uppercase tracking-wide">
            {title}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Planilla Oficial de Control y Registro de Asistencias
          </p>
        </div>

        {/* Statistical Summary Box */}
        <div className="grid grid-cols-5 gap-2 border border-slate-300 rounded-lg p-3 bg-slate-50/50 mb-6 text-center text-xs">
          <div>
            <span className="text-[10px] text-slate-500 block">Total Computado</span>
            <span className="font-mono font-bold text-slate-900 text-sm">{total}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block">Presentes (P)</span>
            <span className="font-mono font-bold text-emerald-700 text-sm">{countP}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block">Ausentes (A)</span>
            <span className="font-mono font-bold text-rose-700 text-sm">{countA}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block">Tardanzas (T)</span>
            <span className="font-mono font-bold text-amber-700 text-sm">{countT}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block">% Presentismo</span>
            <span className="font-mono font-bold text-slate-900 text-sm">{pctAsistencia}%</span>
          </div>
        </div>

        {/* Official Table */}
        <table className="w-full text-left text-xs border border-slate-300 mb-8 border-collapse">
          <thead>
            <tr className="bg-slate-100 border-b border-slate-300 text-[10px] font-bold text-slate-700 uppercase">
              <th className="py-2 px-3 border-r border-slate-300 w-10 text-center">#</th>
              <th className="py-2 px-3 border-r border-slate-300 w-24">Fecha</th>
              <th className="py-2 px-3 border-r border-slate-300 w-24">DNI</th>
              <th className="py-2 px-3 border-r border-slate-300">Apellido y Nombre</th>
              <th className="py-2 px-3 border-r border-slate-300 w-28">Curso</th>
              <th className="py-2 px-3 border-r border-slate-300 w-20 text-center">Estado</th>
              <th className="py-2 px-3">Observaciones / Justificaciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {records.map((r, i) => (
              <tr key={r.id_asistencia} className="odd:bg-white even:bg-slate-50/40">
                <td className="py-1.5 px-3 border-r border-slate-300 text-center font-mono text-slate-500">{i + 1}</td>
                <td className="py-1.5 px-3 border-r border-slate-300 font-mono">{r.fecha}</td>
                <td className="py-1.5 px-3 border-r border-slate-300 font-mono">{r.estudiante?.dni || '—'}</td>
                <td className="py-1.5 px-3 border-r border-slate-300 font-semibold text-slate-900">
                  {r.estudiante ? `${r.estudiante.apellido}, ${r.estudiante.nombre}` : '—'}
                </td>
                <td className="py-1.5 px-3 border-r border-slate-300">{r.curso?.descripcion || '—'}</td>
                <td className="py-1.5 px-3 border-r border-slate-300 text-center font-bold font-mono">
                  {r.estado}
                </td>
                <td className="py-1.5 px-3 text-slate-600">
                  {r.observacion || '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Institutional Signatures Section */}
        <div className="pt-12 grid grid-cols-3 gap-8 text-center text-xs text-slate-600 mt-12 border-t border-slate-200">
          <div>
            <div className="border-t border-slate-400 w-40 mx-auto mb-2" />
            <span className="font-semibold block text-slate-900">Firma del Docente</span>
            <span className="text-[11px] text-slate-400">A cargo del curso</span>
          </div>

          <div>
            <div className="border-t border-slate-400 w-40 mx-auto mb-2" />
            <span className="font-semibold block text-slate-900">Firma de Preceptoría</span>
            <span className="text-[11px] text-slate-400">Verificación de registros</span>
          </div>

          <div>
            <div className="border-t border-slate-400 w-40 mx-auto mb-2" />
            <span className="font-semibold block text-slate-900">Dirección / Rectoría</span>
            <span className="text-[11px] text-slate-400">Sello institucional</span>
          </div>
        </div>
      </div>
    </div>
  );
};
