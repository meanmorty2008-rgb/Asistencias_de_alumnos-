import React, { useState, useEffect } from 'react';
import { Course, AttendanceRecord, AttendanceStatus } from '../types';
import { api } from '../services/api';
import {
  Search,
  Download,
  Printer,
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  FileCheck,
  Filter,
  RefreshCw
} from 'lucide-react';

interface AttendanceHistoryProps {
  courses: Course[];
  onTriggerPrintView: (records: AttendanceRecord[], title: string) => void;
}

export const AttendanceHistory: React.FC<AttendanceHistoryProps> = ({ courses, onTriggerPrintView }) => {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Filters
  const [selectedCursoId, setSelectedCursoId] = useState<string>('all');
  const [selectedEstado, setSelectedEstado] = useState<string>('all');
  const [fechaDesde, setFechaDesde] = useState<string>('2026-10-01');
  const [fechaHasta, setFechaHasta] = useState<string>(() => new Date().toISOString().split('T')[0]);

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const data = await api.queryAttendance({
        id_curso: selectedCursoId !== 'all' ? Number(selectedCursoId) : undefined,
        estado: selectedEstado !== 'all' ? selectedEstado : undefined,
        fecha_desde: fechaDesde || undefined,
        fecha_hasta: fechaHasta || undefined
      });
      setRecords(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, [selectedCursoId, selectedEstado, fechaDesde, fechaHasta]);

  // Counts
  const total = records.length;
  const countP = records.filter(r => r.estado === 'P').length;
  const countA = records.filter(r => r.estado === 'A').length;
  const countT = records.filter(r => r.estado === 'T').length;
  const countAJ = records.filter(r => r.estado === 'AJ').length;

  const pctAsistencia = total > 0 ? ((countP / total) * 100).toFixed(1) : '100';
  const pctInasistencia = total > 0 ? (((countA + countAJ) / total) * 100).toFixed(1) : '0';

  const handleDownloadCsv = () => {
    const url = api.getCsvExportUrl({
      id_curso: selectedCursoId !== 'all' ? Number(selectedCursoId) : undefined,
      fecha_desde: fechaDesde || undefined,
      fecha_hasta: fechaHasta || undefined
    });
    window.open(url, '_blank');
  };

  const handlePrint = () => {
    const courseObj = courses.find(c => c.id_curso === Number(selectedCursoId));
    const title = courseObj
      ? `Planilla Oficial de Asistencia - ${courseObj.anio}° "${courseObj.division}" (${fechaDesde} al ${fechaHasta})`
      : `Planilla General Institucional de Asistencias (${fechaDesde} al ${fechaHasta})`;
    onTriggerPrintView(records, title);
  };

  return (
    <div className="space-y-6">
      {/* Title & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Consultas e Historial de Asistencia
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Filtros avanzados por curso, fecha y estado con exportación en PDF y CSV
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          <button
            type="button"
            onClick={handleDownloadCsv}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            Exportar CSV
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            Generar Informe PDF / Imprimir
          </button>
        </div>
      </div>

      {/* Filter bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Curso */}
          <div>
            <label htmlFor="historial-curso-select" className="block text-xs font-semibold text-slate-700 mb-1">
              Curso y División
            </label>
            <select
              id="historial-curso-select"
              value={selectedCursoId}
              onChange={(e) => setSelectedCursoId(e.target.value)}
              className="w-full h-9.5 px-3 text-xs bg-white border border-slate-300 rounded-lg text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">Todos los Cursos</option>
              {courses.map(c => (
                <option key={c.id_curso} value={c.id_curso}>
                  {c.anio}.º "{c.division}" · Turno {c.turno}
                </option>
              ))}
            </select>
          </div>

          {/* Estado */}
          <div>
            <label htmlFor="historial-estado-select" className="block text-xs font-semibold text-slate-700 mb-1">
              Estado de Asistencia
            </label>
            <select
              id="historial-estado-select"
              value={selectedEstado}
              onChange={(e) => setSelectedEstado(e.target.value)}
              className="w-full h-9.5 px-3 text-xs bg-white border border-slate-300 rounded-lg text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">Todos los Estados (P, A, T, AJ)</option>
              <option value="P">Presente (P)</option>
              <option value="A">Ausente (A)</option>
              <option value="T">Tardanza (T)</option>
              <option value="AJ">Ausente Justificado (AJ)</option>
            </select>
          </div>

          {/* Fecha Desde */}
          <div>
            <label htmlFor="historial-fecha-desde" className="block text-xs font-semibold text-slate-700 mb-1">
              Fecha Desde
            </label>
            <input
              id="historial-fecha-desde"
              type="date"
              value={fechaDesde}
              onChange={(e) => setFechaDesde(e.target.value)}
              className="w-full h-9.5 px-3 text-xs bg-white border border-slate-300 rounded-lg text-slate-700 font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Fecha Hasta */}
          <div>
            <label htmlFor="historial-fecha-hasta" className="block text-xs font-semibold text-slate-700 mb-1">
              Fecha Hasta
            </label>
            <input
              id="historial-fecha-hasta"
              type="date"
              value={fechaHasta}
              onChange={(e) => setFechaHasta(e.target.value)}
              className="w-full h-9.5 px-3 text-xs bg-white border border-slate-300 rounded-lg text-slate-700 font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* KPI metric strip for filtered dataset */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs">
          <span className="text-[11px] font-medium text-slate-500 block">Total Registros</span>
          <span className="text-xl font-bold text-slate-900 font-mono tabular-nums block mt-0.5">
            {total}
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs">
          <span className="text-[11px] font-medium text-emerald-700 block">% Asistencia</span>
          <span className="text-xl font-bold text-emerald-700 font-mono tabular-nums block mt-0.5">
            {pctAsistencia}%
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs">
          <span className="text-[11px] font-medium text-emerald-600 block">Presentes (P)</span>
          <span className="text-xl font-bold text-slate-900 font-mono tabular-nums block mt-0.5">
            {countP}
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs">
          <span className="text-[11px] font-medium text-rose-600 block">Ausentes (A)</span>
          <span className="text-xl font-bold text-rose-600 font-mono tabular-nums block mt-0.5">
            {countA}
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs">
          <span className="text-[11px] font-medium text-amber-600 block">Tardanzas (T)</span>
          <span className="text-xl font-bold text-amber-600 font-mono tabular-nums block mt-0.5">
            {countT}
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs">
          <span className="text-[11px] font-medium text-sky-600 block">Justificadas (AJ)</span>
          <span className="text-xl font-bold text-sky-700 font-mono tabular-nums block mt-0.5">
            {countAJ}
          </span>
        </div>
      </div>

      {/* Table of query results */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-4 py-3 bg-slate-50/70 border-b border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>
            Mostrando <strong>{records.length}</strong> registros encontrados
          </span>
          <button
            type="button"
            onClick={fetchRecords}
            className="flex items-center gap-1 text-slate-600 hover:text-slate-900 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Actualizar
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            Consultando registros en base de datos...
          </div>
        ) : records.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <p className="font-medium text-slate-700">No se encontraron registros para los filtros seleccionados.</p>
            <p className="text-xs text-slate-400 mt-1">Pruebe ampliando el rango de fechas o seleccionando otro curso.</p>
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[600px]">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="sticky top-0 bg-slate-50 z-10 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-4 w-24">Fecha</th>
                  <th className="py-2.5 px-3 w-20">Jornada</th>
                  <th className="py-2.5 px-4 min-w-[140px]">Curso</th>
                  <th className="py-2.5 px-4 min-w-[180px]">Estudiante</th>
                  <th className="py-2.5 px-3 w-24">DNI</th>
                  <th className="py-2.5 px-4 w-32">Estado</th>
                  <th className="py-2.5 px-4 min-w-[180px]">Observación</th>
                  <th className="py-2.5 px-4 min-w-[130px]">Registrado Por</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {records.map((r) => {
                  const badgeMap = {
                    P: { label: 'Presente', style: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
                    A: { label: 'Ausente', style: 'bg-rose-50 text-rose-700 border-rose-200' },
                    T: { label: 'Tardanza', style: 'bg-amber-50 text-amber-700 border-amber-200' },
                    AJ: { label: 'Justificado', style: 'bg-sky-50 text-sky-700 border-sky-200' }
                  }[r.estado];

                  return (
                    <tr key={r.id_asistencia} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2.5 px-4 font-mono tabular-nums font-medium text-slate-800">
                        {r.fecha}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">{r.jornada}</td>
                      <td className="py-2.5 px-4 font-medium text-slate-700">
                        {r.curso?.descripcion || '—'}
                      </td>
                      <td className="py-2.5 px-4 font-semibold text-slate-900">
                        {r.estudiante ? `${r.estudiante.apellido}, ${r.estudiante.nombre}` : '—'}
                      </td>
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-600">
                        {r.estudiante?.dni || '—'}
                      </td>
                      <td className="py-2.5 px-4">
                        <span className={`inline-block px-2 py-0.5 border rounded text-[11px] font-semibold ${badgeMap?.style}`}>
                          {badgeMap?.label} ({r.estado})
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-slate-600">
                        {r.observacion || <span className="text-slate-400 italic">—</span>}
                      </td>
                      <td className="py-2.5 px-4 text-slate-500 text-[11px]">
                        {r.registrado_por || 'Sistema'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
