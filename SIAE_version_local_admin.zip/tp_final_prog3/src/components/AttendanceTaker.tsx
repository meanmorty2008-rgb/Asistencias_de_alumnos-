import React, { useState, useEffect } from 'react';
import { Course, AttendanceStatus, AttendanceSheetItem } from '../types';
import { api } from '../services/api';
import { Check, X, Clock, FileCheck, Save, Calendar, Users, AlertTriangle, RefreshCw, CheckCircle2 } from 'lucide-react';

interface AttendanceTakerProps {
  courses: Course[];
  onRefreshStats?: () => void;
}

export const AttendanceTaker: React.FC<AttendanceTakerProps> = ({ courses, onRefreshStats }) => {
  // Filters
  const [selectedAnio, setSelectedAnio] = useState<number>(1);
  const [selectedCursoId, setSelectedCursoId] = useState<number>(1);
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [selectedJornada, setSelectedJornada] = useState<'Mañana' | 'Tarde'>('Mañana');

  // Attendance local state
  const [sheet, setSheet] = useState<AttendanceSheetItem[]>([]);
  const [attendanceMap, setAttendanceMap] = useState<Record<number, AttendanceStatus>>({});
  const [observationMap, setObservationMap] = useState<Record<number, string>>({});
  const [alreadyRecorded, setAlreadyRecorded] = useState<boolean>(false);
  const [allowEditRecorded, setAllowEditRecorded] = useState<boolean>(false);

  // Status indicators
  const [loading, setLoading] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Available courses filtered by selected year
  const filteredCourses = courses.filter(c => c.anio === selectedAnio);

  // Ensure selectedCursoId corresponds to selected year
  useEffect(() => {
    if (filteredCourses.length > 0) {
      const match = filteredCourses.find(c => c.id_curso === selectedCursoId);
      if (!match) {
        setSelectedCursoId(filteredCourses[0].id_curso);
        setSelectedJornada(filteredCourses[0].turno === 'Tarde' ? 'Tarde' : 'Mañana');
      }
    }
  }, [selectedAnio, courses]);

  // When course changes, adjust jornada default
  const handleCourseChange = (id: number) => {
    setSelectedCursoId(id);
    const c = courses.find(item => item.id_curso === id);
    if (c) {
      setSelectedJornada(c.turno === 'Tarde' ? 'Tarde' : 'Mañana');
    }
  };

  // Load attendance sheet for course, date, and jornada
  const loadSheet = async () => {
    if (!selectedCursoId || !selectedDate) return;
    setLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const data = await api.getAttendanceSheet(selectedCursoId, selectedDate, selectedJornada);
      setSheet(data.alumnos);

      const newAttendanceMap: Record<number, AttendanceStatus> = {};
      const newObsMap: Record<number, string> = {};
      let hasRecorded = false;

      data.alumnos.forEach(item => {
        if (item.asistencia) {
          hasRecorded = true;
          newAttendanceMap[item.estudiante.id_estudiante] = item.asistencia.estado;
          if (item.asistencia.observacion) {
            newObsMap[item.estudiante.id_estudiante] = item.asistencia.observacion;
          }
        }
      });

      setAttendanceMap(newAttendanceMap);
      setObservationMap(newObsMap);
      setAlreadyRecorded(hasRecorded);
      setAllowEditRecorded(false);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error al cargar la nómina de estudiantes.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSheet();
  }, [selectedCursoId, selectedDate, selectedJornada]);

  // Quick state assignment
  const setStatus = (studentId: number, status: AttendanceStatus) => {
    if (alreadyRecorded && !allowEditRecorded) return;
    setAttendanceMap(prev => ({
      ...prev,
      [studentId]: status
    }));
  };

  const setObservation = (studentId: number, text: string) => {
    if (alreadyRecorded && !allowEditRecorded) return;
    setObservationMap(prev => ({
      ...prev,
      [studentId]: text
    }));
  };

  // Bulk actions
  const markAll = (status: AttendanceStatus) => {
    if (alreadyRecorded && !allowEditRecorded) return;
    const newMap: Record<number, AttendanceStatus> = {};
    sheet.forEach(item => {
      newMap[item.estudiante.id_estudiante] = status;
    });
    setAttendanceMap(newMap);
  };

  const clearAll = () => {
    if (alreadyRecorded && !allowEditRecorded) return;
    setAttendanceMap({});
    setObservationMap({});
  };

  // Save attendance
  const handleSave = async () => {
    if (alreadyRecorded && !allowEditRecorded) {
      setErrorMessage('La asistencia ya está registrada para este día y jornada. Debe marcar "Habilitar modificación" para actualizarla.');
      return;
    }

    // Check if at least some students have attendance marked
    const entries = sheet.map(s => {
      const id = s.estudiante.id_estudiante;
      return {
        id_estudiante: id,
        estado: attendanceMap[id] || 'P', // Default to Presente if not marked
        observacion: observationMap[id] || undefined
      };
    });

    if (entries.length === 0) {
      setErrorMessage('No hay estudiantes en este curso para registrar asistencia.');
      return;
    }

    setSaving(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const res = await api.saveBatchAttendance({
        id_curso: selectedCursoId,
        fecha: selectedDate,
        jornada: selectedJornada,
        allowUpdate: alreadyRecorded ? allowEditRecorded : true,
        registros: entries
      });

      setSuccessMessage('¡Asistencia guardada exitosamente en la base de datos!');
      setAlreadyRecorded(true);
      setAllowEditRecorded(false);
      if (onRefreshStats) onRefreshStats();
      // Reload updated sheet
      loadSheet();
    } catch (err: any) {
      if (err.status === 409) {
        setErrorMessage('Conflicto: Ya existe un registro para esta fecha y jornada. Para editarlo, active la opción de modificación.');
      } else {
        setErrorMessage(err.message || 'Error al guardar la asistencia.');
      }
    } finally {
      setSaving(false);
    }
  };

  // Metrics on current sheet
  const totalStudents = sheet.length;
  const countP = sheet.filter(s => attendanceMap[s.estudiante.id_estudiante] === 'P').length;
  const countA = sheet.filter(s => attendanceMap[s.estudiante.id_estudiante] === 'A').length;
  const countT = sheet.filter(s => attendanceMap[s.estudiante.id_estudiante] === 'T').length;
  const countAJ = sheet.filter(s => attendanceMap[s.estudiante.id_estudiante] === 'AJ').length;
  const countPending = totalStudents - (countP + countA + countT + countAJ);

  const currentCourse = courses.find(c => c.id_curso === selectedCursoId);

  return (
    <div className="space-y-6">
      {/* Title & Context */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Toma de Asistencia Diaria
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Registro oficial para 1.º, 2.º y 3.º año · Especialidad Programación
          </p>
        </div>

        {/* Shortcut to today */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const today = new Date().toISOString().split('T')[0];
              setSelectedDate(today);
            }}
            className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
          >
            Ir a Hoy
          </button>
          <button
            onClick={loadSheet}
            disabled={loading}
            className="p-1.5 text-slate-500 hover:text-slate-800 border border-slate-200 rounded-lg bg-white hover:bg-slate-50 transition-colors"
            title="Recargar datos"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Control Panel: Filters for Course, Division, Shift, Date */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 1. Año Escolar */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              1. Año Escolar
            </label>
            <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-lg">
              {[1, 2, 3].map(anio => (
                <button
                  key={anio}
                  type="button"
                  onClick={() => setSelectedAnio(anio)}
                  className={`py-1.5 text-xs font-semibold rounded-md transition-all ${
                    selectedAnio === anio
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {anio}.º Año
                </button>
              ))}
            </div>
          </div>

          {/* 2. Curso y División */}
          <div>
            <label htmlFor="curso-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
              2. Curso y División
            </label>
            <select
              id="curso-select"
              value={selectedCursoId}
              onChange={(e) => handleCourseChange(Number(e.target.value))}
              className="w-full h-9.5 px-3 text-sm bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
            >
              {filteredCourses.map(c => (
                <option key={c.id_curso} value={c.id_curso}>
                  {c.anio}.º "{c.division}" · Turno {c.turno} ({c.cantidad_estudiantes || 0} alumnos)
                </option>
              ))}
            </select>
          </div>

          {/* 3. Fecha */}
          <div>
            <label htmlFor="fecha-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
              3. Fecha del Registro
            </label>
            <div className="relative">
              <input
                id="fecha-select"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full h-9.5 pl-9 pr-3 text-sm bg-white border border-slate-300 rounded-lg text-slate-800 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
              <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            </div>
          </div>

          {/* 4. Jornada / Turno */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              4. Jornada
            </label>
            <div className="grid grid-cols-2 gap-1 bg-slate-100 p-1 rounded-lg">
              {(['Mañana', 'Tarde'] as const).map(j => (
                <button
                  key={j}
                  type="button"
                  onClick={() => setSelectedJornada(j)}
                  className={`py-1.5 text-xs font-semibold rounded-md transition-all ${
                    selectedJornada === j
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {j}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Duplicate Record Notification Banner (Regla Importante) */}
        {alreadyRecorded && (
          <div className="mt-4 pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-amber-50/70 border border-amber-200/80 rounded-lg p-3 text-xs text-amber-900">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                <strong>Registro existente:</strong> La asistencia de <strong>{currentCourse?.anio}° "{currentCourse?.division}"</strong> para el <strong>{selectedDate}</strong> (Jornada {selectedJornada}) ya fue guardada previamente.
              </span>
            </div>
            <label className="inline-flex items-center gap-2 cursor-pointer select-none font-medium text-amber-950">
              <input
                type="checkbox"
                checked={allowEditRecorded}
                onChange={(e) => setAllowEditRecorded(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 border-amber-300 focus:ring-indigo-500"
              />
              <span>Habilitar modificación de registros</span>
            </label>
          </div>
        )}

        {/* Success or Error alert */}
        {successMessage && (
          <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}
        {errorMessage && (
          <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
      </div>

      {/* Sheet Summary Bar & Bulk Actions */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* Quick Metrics Bar */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="font-semibold text-slate-700 flex items-center gap-1.5 mr-2">
              <Users className="w-4 h-4 text-slate-500" />
              Nómina: <span className="font-mono tabular-nums">{totalStudents}</span>
            </span>

            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200/80 rounded-md font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              Presentes (P): <strong className="font-mono tabular-nums">{countP}</strong>
            </span>

            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-rose-50 text-rose-700 border border-rose-200/80 rounded-md font-medium">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              Ausentes (A): <strong className="font-mono tabular-nums">{countA}</strong>
            </span>

            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200/80 rounded-md font-medium">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              Tardanzas (T): <strong className="font-mono tabular-nums">{countT}</strong>
            </span>

            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-sky-50 text-sky-700 border border-sky-200/80 rounded-md font-medium">
              <span className="w-2 h-2 rounded-full bg-sky-500" />
              Justificadas (AJ): <strong className="font-mono tabular-nums">{countAJ}</strong>
            </span>

            {countPending > 0 && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 text-slate-600 rounded-md font-medium">
                Sin marcar: <strong className="font-mono tabular-nums">{countPending}</strong>
              </span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => markAll('P')}
              disabled={alreadyRecorded && !allowEditRecorded}
              className="px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors disabled:opacity-50"
            >
              Todos Presentes
            </button>
            <button
              type="button"
              onClick={() => markAll('A')}
              disabled={alreadyRecorded && !allowEditRecorded}
              className="px-3 py-1.5 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors disabled:opacity-50"
            >
              Todos Ausentes
            </button>
            <button
              type="button"
              onClick={clearAll}
              disabled={alreadyRecorded && !allowEditRecorded}
              className="px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors disabled:opacity-50"
            >
              Limpiar
            </button>

            <button
              type="button"
              onClick={handleSave}
              disabled={saving || (alreadyRecorded && !allowEditRecorded)}
              className="ml-auto lg:ml-2 px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 disabled:opacity-50"
            >
              {saving ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Guardando...
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  {alreadyRecorded ? 'Actualizar Asistencia' : 'Guardar Asistencia'}
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Student Attendance Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        {loading ? (
          <div className="p-12 text-center text-slate-400 text-sm">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-500" />
            Cargando nómina del curso...
          </div>
        ) : sheet.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <Users className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="font-medium text-slate-700">No hay estudiantes activos en este curso.</p>
            <p className="text-xs text-slate-400 mt-1">Diríjase a la sección "Estudiantes" para inscribir alumnos a {currentCourse?.anio}° "{currentCourse?.division}".</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4 w-12 text-center">#</th>
                  <th className="py-3 px-4 w-28">DNI</th>
                  <th className="py-3 px-4 min-w-[200px]">Estudiante (Apellido y Nombre)</th>
                  <th className="py-3 px-4 min-w-[240px]">Estado de Asistencia</th>
                  <th className="py-3 px-4 min-w-[220px]">Observación / Justificación</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {sheet.map((item, index) => {
                  const est = item.estudiante;
                  const currentStatus = attendanceMap[est.id_estudiante];
                  const currentObs = observationMap[est.id_estudiante] || '';
                  const disabled = alreadyRecorded && !allowEditRecorded;

                  return (
                    <tr
                      key={est.id_estudiante}
                      className={`hover:bg-slate-50/60 transition-colors ${
                        currentStatus === 'A'
                          ? 'bg-rose-50/20'
                          : currentStatus === 'T'
                          ? 'bg-amber-50/20'
                          : ''
                      }`}
                    >
                      {/* Row index */}
                      <td className="py-3 px-4 text-center text-xs text-slate-400 font-mono">
                        {index + 1}
                      </td>

                      {/* DNI */}
                      <td className="py-3 px-4 text-xs font-mono text-slate-600 tabular-nums">
                        {est.dni}
                      </td>

                      {/* Student Name */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">
                          {est.apellido}, {est.nombre}
                        </div>
                        {est.telefono_tutor && (
                          <div className="text-[11px] text-slate-400">
                            Tutor: {est.telefono_tutor}
                          </div>
                        )}
                      </td>

                      {/* State Button Group */}
                      <td className="py-3 px-4">
                        <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50 shadow-2xs gap-0.5">
                          {/* Presente */}
                          <button
                            type="button"
                            onClick={() => setStatus(est.id_estudiante, 'P')}
                            disabled={disabled}
                            title="Presente"
                            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all flex items-center gap-1 ${
                              currentStatus === 'P'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-emerald-700 hover:bg-emerald-50'
                            } disabled:opacity-60`}
                          >
                            <Check className="w-3 h-3" />
                            P
                          </button>

                          {/* Ausente */}
                          <button
                            type="button"
                            onClick={() => setStatus(est.id_estudiante, 'A')}
                            disabled={disabled}
                            title="Ausente"
                            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all flex items-center gap-1 ${
                              currentStatus === 'A'
                                ? 'bg-rose-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-rose-700 hover:bg-rose-50'
                            } disabled:opacity-60`}
                          >
                            <X className="w-3 h-3" />
                            A
                          </button>

                          {/* Tardanza */}
                          <button
                            type="button"
                            onClick={() => setStatus(est.id_estudiante, 'T')}
                            disabled={disabled}
                            title="Tardanza"
                            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all flex items-center gap-1 ${
                              currentStatus === 'T'
                                ? 'bg-amber-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-amber-700 hover:bg-amber-50'
                            } disabled:opacity-60`}
                          >
                            <Clock className="w-3 h-3" />
                            T
                          </button>

                          {/* Ausente Justificado */}
                          <button
                            type="button"
                            onClick={() => setStatus(est.id_estudiante, 'AJ')}
                            disabled={disabled}
                            title="Ausente Justificado"
                            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all flex items-center gap-1 ${
                              currentStatus === 'AJ'
                                ? 'bg-sky-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-sky-700 hover:bg-sky-50'
                            } disabled:opacity-60`}
                          >
                            <FileCheck className="w-3 h-3" />
                            AJ
                          </button>
                        </div>
                      </td>

                      {/* Observation */}
                      <td className="py-3 px-4">
                        <input
                          type="text"
                          value={currentObs}
                          onChange={(e) => setObservation(est.id_estudiante, e.target.value)}
                          disabled={disabled}
                          placeholder={
                            currentStatus === 'AJ'
                              ? 'Motivo o n.° de certificado...'
                              : currentStatus === 'T'
                              ? 'Hora de llegada o motivo...'
                              : 'Observación opcional...'
                          }
                          className="w-full text-xs px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 disabled:bg-slate-50 disabled:text-slate-400"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Footer info & save */}
        <div className="bg-slate-50/80 px-4 py-3 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div>
            <span>Estado: </span>
            <span className="font-medium text-slate-700">
              {alreadyRecorded
                ? 'Asistencia guardada en base de datos.'
                : 'Pendiente de confirmación para esta fecha.'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleSave}
              disabled={saving || (alreadyRecorded && !allowEditRecorded)}
              className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              {saving ? 'Guardando...' : alreadyRecorded ? 'Guardar Cambios' : 'Confirmar y Guardar Asistencia'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
