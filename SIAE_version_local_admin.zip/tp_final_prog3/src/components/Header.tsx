import React from 'react';
import { useAuth } from '../context/AuthContext';
import { LogOut, User as UserIcon, Shield, Laptop } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenLogin: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentTab, onSelectTab, onOpenLogin }) => {
  const { user, logout, switchDemoUser } = useAuth();

  const navLinks = [
    { id: 'asistencia', label: 'Tomar Asistencia' },
    { id: 'cursos', label: 'Cursos' },
    { id: 'estudiantes', label: 'Estudiantes' },
    { id: 'historial', label: 'Consultas' },
    { id: 'estadisticas', label: 'Estadísticas' },
    { id: 'render', label: 'Despliegue Render' }
  ];

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Brand title, single line */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onSelectTab('asistencia')}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
            >
              <div className="w-9 h-9 rounded-lg bg-indigo-900 flex items-center justify-center text-amber-300 shadow-sm overflow-hidden shrink-0">
                <img
                  src="/src/assets/images/school_emblem_logo_1793823363255.jpg"
                  alt="Escudo Institucional"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    // Fallback to vector icon if image fails
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
              <div className="whitespace-nowrap">
                <span className="font-bold text-base text-slate-900 tracking-tight block">
                  SIAE <span className="text-indigo-600 font-semibold text-xs ml-1 font-mono">6.° PROG</span>
                </span>
                <span className="text-[11px] text-slate-500 font-medium block">
                  Control de Asistencia Escolar
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: 4-5 single-line clean navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 overflow-x-auto py-1">
            {navLinks.map(link => {
              const active = currentTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => onSelectTab(link.id)}
                  className={`whitespace-nowrap shrink-0 transition-colors py-1 relative ${
                    active
                      ? 'text-indigo-600 font-semibold'
                      : 'hover:text-slate-900 text-slate-600'
                  }`}
                >
                  {link.label}
                  {active && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            {user ? (
              <div className="flex items-center gap-2.5">
                {/* Switcher rápido de roles pedagógicos */}
                <div className="hidden lg:flex items-center border border-slate-200 rounded-md bg-slate-50 p-0.5 text-xs">
                  <span className="text-slate-500 px-2 py-0.5 text-[11px]">Rol:</span>
                  <button
                    onClick={() => switchDemoUser('admin')}
                    className={`px-2 py-0.5 rounded text-xs transition-colors ${
                      user.rol === 'administrador'
                        ? 'bg-white shadow-xs font-semibold text-indigo-700'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="Rol Administrador (Rectoría / Acceso total)"
                  >
                    Admin
                  </button>
                  <button
                    onClick={() => switchDemoUser('preceptor')}
                    className={`px-2 py-0.5 rounded text-xs transition-colors ${
                      user.rol === 'preceptor'
                        ? 'bg-white shadow-xs font-semibold text-indigo-700'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="Rol Preceptoría (Asistencia y alumnos)"
                  >
                    Preceptor
                  </button>
                  <button
                    onClick={() => switchDemoUser('docente')}
                    className={`px-2 py-0.5 rounded text-xs transition-colors ${
                      user.rol === 'docente'
                        ? 'bg-white shadow-xs font-semibold text-indigo-700'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="Rol Docente (Toma y consulta de su curso)"
                  >
                    Docente
                  </button>
                </div>

                <div className="text-right hidden sm:block">
                  <span className="block text-xs font-semibold text-slate-900 truncate max-w-[140px]">
                    {user.nombre_completo.split(' ')[0]} {user.nombre_completo.split(' ')[1] || ''}
                  </span>
                  <span className="block text-[10px] text-slate-500 capitalize">
                    {user.rol}
                  </span>
                </div>

                <button
                  onClick={logout}
                  className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  title="Cerrar sesión"
                  aria-label="Cerrar sesión"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenLogin}
                className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
              >
                <UserIcon className="w-3.5 h-3.5" />
                Iniciar Sesión
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
