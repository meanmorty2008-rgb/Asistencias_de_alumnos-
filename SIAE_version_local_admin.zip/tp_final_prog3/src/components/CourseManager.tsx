import React, { useState } from 'react';
import { Course, Student } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Plus, Users, Edit2, Trash2, X, Check, BookOpen, AlertCircle } from 'lucide-react';

interface CourseManagerProps {
  courses: Course[];
  onRefreshCourses: () => void;
  onSelectCourseForAttendance?: (courseId: number) => void;
}

export const CourseManager: React.FC<CourseManagerProps> = ({
  courses,
  onRefreshCourses,
  onSelectCourseForAttendance
}) => {
  const { canManageCourses } = useAuth();
  const [filterAnio, setFilterAnio] = useState<number | 'all'>('all');

  // Modal for new/edit course
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [formAnio, setFormAnio] = useState<number>(1);
  const [formDivision, setFormDivision] = useState<string>('A');
  const [formTurno, setFormTurno] = useState<'Mañana' | 'Tarde' | 'Vespertino'>('Mañana');
  const [formEspecialidad, setFormEspecialidad] = useState<string>('Ciclo Básico');
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Modal to inspect students of a course
  const [viewingCourse, setViewingCourse] = useState<Course | null>(null);
  const [courseStudents, setCourseStudents] = useState<Student[]>([]);
  const [loadingStudents, setLoadingStudents] = useState<boolean>(false);

  const filteredCourses = filterAnio === 'all'
    ? courses
    : courses.filter(c => c.anio === filterAnio);

  const openCreateModal = () => {
    setEditingCourse(null);
    setFormAnio(1);
    setFormDivision('D');
    setFormTurno('Mañana');
    setFormEspecialidad('Ciclo Básico');
    setFormError(null);
    setModalOpen(true);
  };

  const openEditModal = (c: Course) => {
    setEditingCourse(c);
    setFormAnio(c.anio);
    setFormDivision(c.division);
    setFormTurno(c.turno);
    setFormEspecialidad(c.especialidad || (c.anio === 3 ? 'Introducción a Programación' : 'Ciclo Básico'));
    setFormError(null);
    setModalOpen(true);
  };

  const handleSaveCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setFormError(null);

    try {
      if (editingCourse) {
        await api.updateCurso(editingCourse.id_curso, {
          anio: formAnio,
          division: formDivision.toUpperCase().trim(),
          turno: formTurno,
          especialidad: formEspecialidad
        });
      } else {
        await api.createCurso({
          anio: formAnio,
          division: formDivision.toUpperCase().trim(),
          turno: formTurno,
          especialidad: formEspecialidad
        });
      }
      setModalOpen(false);
      onRefreshCourses();
    } catch (err: any) {
      setFormError(err.message || 'Error al guardar el curso.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteCourse = async (course: Course) => {
    if (!window.confirm(`¿Está seguro de eliminar el curso ${course.anio}° "${course.division}"?`)) {
      return;
    }

    try {
      await api.deleteCurso(course.id_curso);
      onRefreshCourses();
    } catch (err: any) {
      alert(err.message || 'No se pudo eliminar el curso.');
    }
  };

  const handleViewStudents = async (c: Course) => {
    setViewingCourse(c);
    setLoadingStudents(true);
    try {
      const students = await api.getEstudiantes({ id_curso: c.id_curso, estado: true });
      setCourseStudents(students);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoadingStudents(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Gestión de Cursos y Divisiones
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Administración de cursos de 1.º, 2.º y 3.º año del ciclo secundario técnico
          </p>
        </div>

        {canManageCourses && (
          <button
            type="button"
            onClick={openCreateModal}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            Nueva División / Curso
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit">
        <button
          type="button"
          onClick={() => setFilterAnio('all')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            filterAnio === 'all'
              ? 'bg-white text-slate-900 shadow-xs font-semibold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Todos los Cursos
        </button>
        {[1, 2, 3].map(yr => (
          <button
            key={yr}
            type="button"
            onClick={() => setFilterAnio(yr)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              filterAnio === yr
                ? 'bg-white text-indigo-700 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {yr}.º Año
          </button>
        ))}
      </div>

      {/* Course Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCourses.map(course => (
          <div
            key={course.id_curso}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-xs font-medium text-indigo-600 block mb-0.5">
                    {course.anio}.º Año
                  </span>
                  <h3 className="text-xl font-bold text-slate-900 tracking-tight">
                    División "{course.division}"
                  </h3>
                </div>
                <span className="text-xs font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                  Turno {course.turno}
                </span>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Orientación:</span>
                  <span className="font-medium text-slate-800">{course.especialidad || 'Ciclo Básico'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Matrícula activa:</span>
                  <span className="font-semibold text-slate-900 font-mono tabular-nums">
                    {course.cantidad_estudiantes || 0} estudiantes
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => handleViewStudents(course)}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors flex items-center gap-1.5"
              >
                <Users className="w-3.5 h-3.5 text-slate-500" />
                Ver Alumnos ({course.cantidad_estudiantes || 0})
              </button>

              <div className="flex items-center gap-1">
                {onSelectCourseForAttendance && (
                  <button
                    type="button"
                    onClick={() => onSelectCourseForAttendance(course.id_curso)}
                    className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors"
                    title="Tomar asistencia a este curso"
                  >
                    <BookOpen className="w-4 h-4" />
                  </button>
                )}
                {canManageCourses && (
                  <>
                    <button
                      type="button"
                      onClick={() => openEditModal(course)}
                      className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors"
                      title="Editar curso"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteCourse(course)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                      title="Eliminar curso"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Create / Edit Course */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="font-semibold text-slate-900 text-sm">
                {editingCourse ? 'Modificar Curso' : 'Registrar Nuevo Curso / División'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCourse} className="p-5 space-y-4">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Año Académico
                </label>
                <select
                  value={formAnio}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setFormAnio(val);
                    if (val === 3) setFormEspecialidad('Introducción a Programación');
                  }}
                  className="w-full text-xs h-9 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value={1}>1.º Año (Ciclo Básico)</option>
                  <option value={2}>2.º Año (Ciclo Básico)</option>
                  <option value={3}>3.º Año (Ciclo Básico / Programación)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  División (Letra o Identificador)
                </label>
                <input
                  type="text"
                  required
                  maxLength={5}
                  value={formDivision}
                  onChange={(e) => setFormDivision(e.target.value.toUpperCase())}
                  placeholder="Ej: A, B, C, D"
                  className="w-full text-xs h-9 px-3 border border-slate-300 rounded-lg font-mono uppercase focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Turno
                </label>
                <select
                  value={formTurno}
                  onChange={(e) => setFormTurno(e.target.value as any)}
                  className="w-full text-xs h-9 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="Mañana">Turno Mañana</option>
                  <option value="Tarde">Turno Tarde</option>
                  <option value="Vespertino">Turno Vespertino</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Orientación / Especialidad
                </label>
                <input
                  type="text"
                  value={formEspecialidad}
                  onChange={(e) => setFormEspecialidad(e.target.value)}
                  placeholder="Ciclo Básico / Programación"
                  className="w-full text-xs h-9 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 border border-slate-200 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm disabled:opacity-50"
                >
                  {submitting ? 'Guardando...' : editingCourse ? 'Actualizar Curso' : 'Crear Curso'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: View Enrolled Students */}
      {viewingCourse && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-slate-900 text-sm">
                  Estudiantes de {viewingCourse.anio}.º "{viewingCourse.division}"
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Turno {viewingCourse.turno} · {viewingCourse.especialidad}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setViewingCourse(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1">
              {loadingStudents ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  Cargando nómina...
                </div>
              ) : courseStudents.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500">
                  No hay estudiantes inscriptos actualmente en este curso.
                </div>
              ) : (
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                      <th className="py-2 px-3">#</th>
                      <th className="py-2 px-3">DNI</th>
                      <th className="py-2 px-3">Apellido y Nombre</th>
                      <th className="py-2 px-3">Tutor / Teléfono</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {courseStudents.map((st, i) => (
                      <tr key={st.id_estudiante} className="hover:bg-slate-50">
                        <td className="py-2 px-3 text-slate-400 font-mono">{i + 1}</td>
                        <td className="py-2 px-3 font-mono tabular-nums text-slate-700">{st.dni}</td>
                        <td className="py-2 px-3 font-medium text-slate-900">{st.apellido}, {st.nombre}</td>
                        <td className="py-2 px-3 text-slate-500">{st.telefono_tutor || 'No especificado'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex justify-end">
              <button
                type="button"
                onClick={() => setViewingCourse(null)}
                className="px-4 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
