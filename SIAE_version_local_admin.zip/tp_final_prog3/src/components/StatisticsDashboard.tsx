import React, { useState, useEffect } from 'react';
import { StatisticsResponse } from '../types';
import { api } from '../services/api';
import {
  TrendingUp,
  AlertTriangle,
  Award,
  BarChart3,
  Calendar,
  Users,
  CheckCircle,
  XCircle,
  Clock,
  FileCheck,
  RefreshCw
} from 'lucide-react';

interface StatisticsDashboardProps {
  onSelectStudentForHistory?: (studentId: number) => void;
}

export const StatisticsDashboard: React.FC<StatisticsDashboardProps> = () => {
  const [stats, setStats] = useState<StatisticsResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchStats = async () => {
    setLoading(true);
    try {
      const data = await api.getStatistics();
      setStats(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="p-16 text-center text-slate-400">
        <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-2 text-indigo-500" />
        <p className="text-sm font-medium text-slate-600">Calculando indicadores y estadísticas escolares...</p>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="p-8 bg-white border border-slate-200 rounded-xl text-center">
        <p className="text-sm text-slate-600">No se pudieron cargar las estadísticas institucionales.</p>
        <button
          onClick={fetchStats}
          className="mt-3 px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg"
        >
          Reintentar
        </button>
      </div>
    );
  }

  const { resumen, cursos, top_ausencias, tendencia_diaria } = stats;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Panel Estadístico e Indicadores Institucionales
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Seguimiento de presentismo, ausentismo crítico y comparativa entre cursos de 1.º a 3.º año
          </p>
        </div>

        <button
          type="button"
          onClick={fetchStats}
          className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Actualizar Estadísticas
        </button>
      </div>

      {/* Main KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Estudiantes */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Matrícula Activa</span>
            <Users className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-slate-900 font-mono tabular-nums">
              {resumen.total_estudiantes}
            </span>
            <span className="text-xs text-slate-500">en {resumen.total_cursos} divisiones</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            Ciclo Básico y Especialidad Programación
          </div>
        </div>

        {/* % Asistencia Global */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-700">Porcentaje de Asistencia</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-emerald-700 font-mono tabular-nums">
              {resumen.porcentaje_asistencia}%
            </span>
            <span className="text-xs text-slate-500 font-mono tabular-nums">({resumen.presentes} P)</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            Total sobre {resumen.total_registros} asistencias computadas
          </div>
        </div>

        {/* % Inasistencia Global */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-rose-700">Porcentaje de Inasistencia</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-rose-700 font-mono tabular-nums">
              {resumen.porcentaje_inasistencia}%
            </span>
            <span className="text-xs text-slate-500 font-mono tabular-nums">({resumen.ausentes} A + {resumen.ausentes_justificados} AJ)</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            Incluye ausencias con y sin justificación médica
          </div>
        </div>

        {/* Tardanzas y Puntualidad */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-700">Registro de Tardanzas</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-amber-700 font-mono tabular-nums">
              {resumen.tardanzas}
            </span>
            <span className="text-xs text-slate-500">ingresos con demora</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            Cómputo institucional: 0.5 inasistencia por tardanza
          </div>
        </div>
      </div>

      {/* Grid: Course Comparison + Daily Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Comparación de Asistencia entre Cursos (Requerimiento Módulo 5) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-slate-900 text-sm">
                Comparación de Asistencia entre Cursos
              </h3>
              <p className="text-xs text-slate-500">
                Porcentaje de presentismo por año y división (1.º, 2.º y 3.º año)
              </p>
            </div>
            <BarChart3 className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-3.5">
            {cursos.map((c) => {
              const pct = c.porcentaje_asistencia;
              const isHigh = pct >= 85;
              const isMed = pct >= 75 && pct < 85;

              return (
                <div key={c.id_curso} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800">
                      {c.nombre}
                    </span>
                    <div className="flex items-center gap-3">
                      <span className="text-[11px] text-slate-400">
                        {c.presentes}P / {c.ausentes}A / {c.tardanzas}T
                      </span>
                      <span className="font-mono font-bold tabular-nums text-slate-900 w-12 text-right">
                        {pct}%
                      </span>
                    </div>
                  </div>

                  {/* Progress visual bar */}
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden flex">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        isHigh ? 'bg-emerald-500' : isMed ? 'bg-amber-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tendencia Diaria de los Últimos Días Registrados */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-slate-900 text-sm">
                  Tendencia de Asistencia por Fecha
                </h3>
                <p className="text-xs text-slate-500">
                  Desglose cronológico de las jornadas escolares recientes
                </p>
              </div>
              <Calendar className="w-4 h-4 text-slate-400" />
            </div>

            <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
              {tendencia_diaria.map((dia) => (
                <div
                  key={dia.fecha}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50/70 border border-slate-100 text-xs"
                >
                  <div>
                    <span className="font-mono font-semibold text-slate-900 tabular-nums">
                      {dia.fecha}
                    </span>
                    <span className="text-[11px] text-slate-400 ml-2">
                      ({dia.total} alumnos registrados)
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-emerald-700 font-mono">
                      {dia.presentes} P
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="text-[11px] text-rose-700 font-mono">
                      {dia.ausentes} A
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="px-2 py-0.5 bg-white border border-slate-200 rounded text-[11px] font-bold font-mono text-slate-800">
                      {dia.tasa_asistencia}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Rango de análisis: Período lectivo en curso</span>
            <span>Meta institucional: &gt; 85%</span>
          </div>
        </div>
      </div>

      {/* Estudiantes con Mayor Cantidad de Ausencias (Seguimiento Institucional) */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-5 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h3 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              Estudiantes con Mayor Cantidad de Inasistencias
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Alumnos con riesgo de pérdida de regularidad o superación del límite institucional de faltas
            </p>
          </div>
          <span className="text-xs text-slate-400">
            Reglamento: 1 Falta = 1.0 · 1 Tardanza = 0.5
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase">
                <th className="py-2.5 px-4 w-12 text-center">#</th>
                <th className="py-2.5 px-4">Estudiante</th>
                <th className="py-2.5 px-4">DNI</th>
                <th className="py-2.5 px-4">Curso</th>
                <th className="py-2.5 px-3 text-center">Injustificadas (A)</th>
                <th className="py-2.5 px-3 text-center">Justificadas (AJ)</th>
                <th className="py-2.5 px-3 text-center">Tardanzas (T)</th>
                <th className="py-2.5 px-4 text-center font-bold text-slate-700">Total Computado</th>
                <th className="py-2.5 px-4 text-center">Situación</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {top_ausencias.map((est, index) => (
                <tr key={est.id_estudiante} className="hover:bg-slate-50/70">
                  <td className="py-2.5 px-4 text-center font-mono text-slate-400">{index + 1}</td>
                  <td className="py-2.5 px-4 font-semibold text-slate-900">
                    {est.nombre_completo}
                  </td>
                  <td className="py-2.5 px-4 font-mono tabular-nums text-slate-600">
                    {est.dni}
                  </td>
                  <td className="py-2.5 px-4 font-medium text-slate-700">
                    {est.curso}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono font-semibold text-rose-700">
                    {est.ausencias_injustificadas}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono text-sky-700">
                    {est.ausencias_justificadas}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono text-amber-700">
                    {est.tardanzas}
                  </td>
                  <td className="py-2.5 px-4 text-center font-mono font-bold tabular-nums text-slate-900 bg-slate-50">
                    {est.inasistencias_computadas}
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    {est.alerta_reincorporacion ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                        Alerta Inasistencias
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-amber-50 text-amber-700 border border-amber-200">
                        Seguimiento
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
