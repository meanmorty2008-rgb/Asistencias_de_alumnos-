export type AttendanceStatus = 'P' | 'A' | 'T' | 'AJ';

export interface User {
  id_usuario: number;
  nombre_usuario: string;
  rol: 'administrador' | 'docente' | 'preceptor';
  nombre_completo: string;
  email: string;
}

export interface Course {
  id_curso: number;
  anio: number;
  division: string;
  turno: 'Mañana' | 'Tarde' | 'Vespertino';
  especialidad?: string;
  cantidad_estudiantes?: number;
}

export interface Student {
  id_estudiante: number;
  dni: string;
  apellido: string;
  nombre: string;
  id_curso: number;
  estado: boolean;
  telefono_tutor?: string;
  email_tutor?: string;
  curso_descripcion?: string;
  anio?: number;
  division?: string;
  turno?: string;
}

export interface AttendanceRecord {
  id_asistencia: number;
  id_estudiante: number;
  fecha: string;
  estado: AttendanceStatus;
  observacion?: string;
  id_usuario: number;
  jornada: 'Mañana' | 'Tarde';
  creado_el?: string;
  estudiante?: {
    id_estudiante: number;
    dni: string;
    apellido: string;
    nombre: string;
  } | null;
  curso?: {
    id_curso: number;
    descripcion: string;
  } | null;
  registrado_por?: string;
}

export interface AttendanceSheetItem {
  estudiante: Student;
  asistencia: AttendanceRecord | null;
}

export interface AttendanceSheetResponse {
  id_curso: number;
  fecha: string;
  jornada: 'Mañana' | 'Tarde';
  counts: {
    total: number;
    registrados: number;
    presentes: number;
    ausentes: number;
    tardanzas: number;
    ausentes_justificados: number;
  };
  alumnos: AttendanceSheetItem[];
}

export interface StudentHistoryResponse {
  estudiante: Student & { curso?: Course };
  total_dias: number;
  presentes: number;
  ausentes: number;
  tardanzas: number;
  ausentes_justificados: number;
  porcentaje_asistencia: number;
  porcentaje_inasistencia: number;
  historial: AttendanceRecord[];
}

export interface CourseStat {
  id_curso: number;
  anio: number;
  division: string;
  turno: string;
  nombre: string;
  estudiantes: number;
  total_asistencias: number;
  presentes: number;
  ausentes: number;
  tardanzas: number;
  ausentes_justificados: number;
  porcentaje_asistencia: number;
}

export interface TopAbsentStudent {
  id_estudiante: number;
  dni: string;
  nombre_completo: string;
  curso: string;
  total_dias: number;
  ausencias_injustificadas: number;
  ausencias_justificadas: number;
  tardanzas: number;
  inasistencias_computadas: number;
  alerta_reincorporacion: boolean;
}

export interface DailyTrend {
  fecha: string;
  total: number;
  presentes: number;
  ausentes: number;
  tardanzas: number;
  ausentes_justificados: number;
  tasa_asistencia: number;
}

export interface StatisticsResponse {
  resumen: {
    total_estudiantes: number;
    total_cursos: number;
    total_registros: number;
    presentes: number;
    ausentes: number;
    tardanzas: number;
    ausentes_justificados: number;
    porcentaje_asistencia: number;
    porcentaje_inasistencia: number;
  };
  cursos: CourseStat[];
  top_ausencias: TopAbsentStudent[];
  tendencia_diaria: DailyTrend[];
}
