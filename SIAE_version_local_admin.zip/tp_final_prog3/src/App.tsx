/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Header } from './components/Header';
import { AttendanceTaker } from './components/AttendanceTaker';
import { CourseManager } from './components/CourseManager';
import { StudentManager } from './components/StudentManager';
import { AttendanceHistory } from './components/AttendanceHistory';
import { StatisticsDashboard } from './components/StatisticsDashboard';
import { RenderDeploymentGuide } from './components/RenderDeploymentGuide';
import { PrintableAttendanceReport } from './components/PrintableAttendanceReport';
import { LoginModal } from './components/LoginModal';
import { Course, AttendanceRecord } from './types';
import { api } from './services/api';
import {
  BookOpen,
  CalendarCheck,
  GraduationCap,
  Users,
  BarChart2,
  Globe,
  FileSpreadsheet
} from 'lucide-react';

function AppContent() {
  const { user } = useAuth();
  const [currentTab, setCurrentTab] = useState<string>('asistencia');
  const [courses, setCourses] = useState<Course[]>([]);
  const [loginModalOpen, setLoginModalOpen] = useState<boolean>(false);

  // Printable report state
  const [printRecords, setPrintRecords] = useState<AttendanceRecord[] | null>(null);
  const [printTitle, setPrintTitle] = useState<string>('');

  const loadCourses = async () => {
    try {
      const data = await api.getCursos();
      setCourses(data);
    } catch (err) {
      console.error('Error fetching courses:', err);
    }
  };

  useEffect(() => {
    loadCourses();
  }, []);

  const handleSelectCourseForAttendance = (courseId: number) => {
    setCurrentTab('asistencia');
  };

  const handleTriggerPrintView = (records: AttendanceRecord[], title: string) => {
    setPrintRecords(records);
    setPrintTitle(title);
  };

  const handleBackFromPrint = () => {
    setPrintRecords(null);
    setPrintTitle('');
  };

  // If printable report is active, render print-first layout
  if (printRecords) {
    return (
      <div className="min-h-screen bg-slate-100 py-6 px-4">
        <PrintableAttendanceReport
          records={printRecords}
          title={printTitle}
          onBack={handleBackFromPrint}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Bar Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenLogin={() => setLoginModalOpen(true)}
      />

      {/* Mobile Quick Tab Navigation */}
      <div className="md:hidden bg-white border-b border-slate-200 px-4 py-2 overflow-x-auto flex items-center gap-2 text-xs font-medium no-print">
        {[
          { id: 'asistencia', label: 'Tomar Asistencia' },
          { id: 'cursos', label: 'Cursos' },
          { id: 'estudiantes', label: 'Estudiantes' },
          { id: 'historial', label: 'Historial' },
          { id: 'estadisticas', label: 'Estadísticas' },
          { id: 'render', label: 'Render' }
        ].map(item => (
          <button
            key={item.id}
            onClick={() => setCurrentTab(item.id)}
            className={`whitespace-nowrap px-3 py-1.5 rounded-lg transition-colors ${
              currentTab === item.id
                ? 'bg-indigo-600 text-white font-semibold'
                : 'bg-slate-100 text-slate-600'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {currentTab === 'asistencia' && (
          <AttendanceTaker
            courses={courses}
            onRefreshStats={loadCourses}
          />
        )}

        {currentTab === 'cursos' && (
          <CourseManager
            courses={courses}
            onRefreshCourses={loadCourses}
            onSelectCourseForAttendance={handleSelectCourseForAttendance}
          />
        )}

        {currentTab === 'estudiantes' && (
          <StudentManager
            courses={courses}
          />
        )}

        {currentTab === 'historial' && (
          <AttendanceHistory
            courses={courses}
            onTriggerPrintView={handleTriggerPrintView}
          />
        )}

        {currentTab === 'estadisticas' && (
          <StatisticsDashboard />
        )}

        {currentTab === 'render' && (
          <RenderDeploymentGuide />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 px-4 no-print mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">SIAE</span>
            <span>·</span>
            <span>Escuela de Educación Secundaria Técnica · 6.º Año Especialidad Programación</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span>Base de datos relacional</span>
            <span>·</span>
            <span>Despliegue Render Ready</span>
            <span>·</span>
            <button
              onClick={() => setCurrentTab('render')}
              className="text-indigo-600 hover:underline font-medium"
            >
              Guía Técnica
            </button>
          </div>
        </div>
      </footer>

      {/* Login Modal */}
      <LoginModal
        isOpen={loginModalOpen}
        onClose={() => setLoginModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
