import {
  User,
  Course,
  Student,
  AttendanceRecord,
  AttendanceSheetResponse,
  StudentHistoryResponse,
  StatisticsResponse,
  AttendanceStatus
} from '../types';

const TOKEN_KEY = 'siae_token';

export const api = {
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  },

  setToken(token: string) {
    localStorage.setItem(TOKEN_KEY, token);
  },

  removeToken() {
    localStorage.removeItem(TOKEN_KEY);
  },

  getHeaders(): HeadersInit {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json'
    };
    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  },

  // Auth
  async login(username: string, password: string): Promise<{ token: string; usuario: User }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error al iniciar sesión' }));
      throw new Error(err.error || 'Error al iniciar sesión');
    }
    const data = await res.json();
    this.setToken(data.token);
    return data;
  },

  async getMe(): Promise<{ usuario: User }> {
    const res = await fetch('/api/auth/me', {
      headers: this.getHeaders()
    });
    if (!res.ok) {
      throw new Error('No autorizado');
    }
    return res.json();
  },

  async logout(): Promise<void> {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: this.getHeaders()
      });
    } finally {
      this.removeToken();
    }
  },

  // Cursos
  async getCursos(): Promise<Course[]> {
    const res = await fetch('/api/cursos', { headers: this.getHeaders() });
    if (!res.ok) throw new Error('Error al cargar cursos');
    return res.json();
  },

  async createCurso(data: { anio: number; division: string; turno: string; especialidad?: string }): Promise<Course> {
    const res = await fetch('/api/cursos', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error al crear curso' }));
      throw new Error(err.error || 'Error al crear curso');
    }
    return res.json();
  },

  async updateCurso(id: number, data: Partial<Course>): Promise<Course> {
    const res = await fetch(`/api/cursos/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error al actualizar curso' }));
      throw new Error(err.error || 'Error al actualizar curso');
    }
    return res.json();
  },

  async deleteCurso(id: number): Promise<void> {
    const res = await fetch(`/api/cursos/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error al eliminar curso' }));
      throw new Error(err.error || 'Error al eliminar curso');
    }
  },

  // Estudiantes
  async getEstudiantes(params?: {
    id_curso?: number;
    anio?: number;
    division?: string;
    search?: string;
    estado?: boolean;
  }): Promise<Student[]> {
    const query = new URLSearchParams();
    if (params?.id_curso) query.set('id_curso', String(params.id_curso));
    if (params?.anio) query.set('anio', String(params.anio));
    if (params?.division) query.set('division', params.division);
    if (params?.search) query.set('search', params.search);
    if (params?.estado !== undefined) query.set('estado', String(params.estado));

    const res = await fetch(`/api/estudiantes?${query.toString()}`, {
      headers: this.getHeaders()
    });
    if (!res.ok) throw new Error('Error al cargar estudiantes');
    return res.json();
  },

  async createEstudiante(data: {
    dni: string;
    apellido: string;
    nombre: string;
    id_curso: number;
    estado?: boolean;
    telefono_tutor?: string;
    email_tutor?: string;
  }): Promise<Student> {
    const res = await fetch('/api/estudiantes', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error al crear estudiante' }));
      throw new Error(err.error || 'Error al crear estudiante');
    }
    return res.json();
  },

  async updateEstudiante(id: number, data: Partial<Student>): Promise<Student> {
    const res = await fetch(`/api/estudiantes/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error al actualizar estudiante' }));
      throw new Error(err.error || 'Error al actualizar estudiante');
    }
    return res.json();
  },

  async deleteEstudiante(id: number, hard: boolean = false): Promise<void> {
    const res = await fetch(`/api/estudiantes/${id}?hard=${hard}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error al dar de baja estudiante' }));
      throw new Error(err.error || 'Error al dar de baja estudiante');
    }
  },

  // Asistencia
  async getAttendanceSheet(id_curso: number, fecha: string, jornada: string): Promise<AttendanceSheetResponse> {
    const res = await fetch(`/api/asistencias/sheet?id_curso=${id_curso}&fecha=${fecha}&jornada=${jornada}`, {
      headers: this.getHeaders()
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error al cargar planilla de asistencia' }));
      throw new Error(err.error || 'Error al cargar planilla de asistencia');
    }
    return res.json();
  },

  async saveBatchAttendance(data: {
    id_curso: number;
    fecha: string;
    jornada: 'Mañana' | 'Tarde';
    allowUpdate?: boolean;
    registros: {
      id_estudiante: number;
      estado: AttendanceStatus;
      observacion?: string;
    }[];
  }): Promise<{ message: string; data: AttendanceSheetResponse }> {
    const res = await fetch('/api/asistencias/batch', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Error al registrar asistencias' }));
      const error: any = new Error(err.error || 'Error al registrar asistencias');
      error.status = res.status;
      throw error;
    }
    return res.json();
  },

  async queryAttendance(filters: {
    id_curso?: number;
    id_estudiante?: number;
    fecha_desde?: string;
    fecha_hasta?: string;
    estado?: string;
  }): Promise<AttendanceRecord[]> {
    const query = new URLSearchParams();
    if (filters.id_curso) query.set('id_curso', String(filters.id_curso));
    if (filters.id_estudiante) query.set('id_estudiante', String(filters.id_estudiante));
    if (filters.fecha_desde) query.set('fecha_desde', filters.fecha_desde);
    if (filters.fecha_hasta) query.set('fecha_hasta', filters.fecha_hasta);
    if (filters.estado) query.set('estado', filters.estado);

    const res = await fetch(`/api/asistencias/query?${query.toString()}`, {
      headers: this.getHeaders()
    });
    if (!res.ok) throw new Error('Error al consultar historial de asistencias');
    return res.json();
  },

  async getStudentHistory(id_estudiante: number): Promise<StudentHistoryResponse> {
    const res = await fetch(`/api/asistencias/estudiante/${id_estudiante}`, {
      headers: this.getHeaders()
    });
    if (!res.ok) throw new Error('Error al obtener historial del estudiante');
    return res.json();
  },

  // Estadísticas
  async getStatistics(): Promise<StatisticsResponse> {
    const res = await fetch('/api/estadisticas', {
      headers: this.getHeaders()
    });
    if (!res.ok) throw new Error('Error al cargar estadísticas');
    return res.json();
  },

  // Exportar CSV URL
  getCsvExportUrl(filters: { id_curso?: number; fecha_desde?: string; fecha_hasta?: string }): string {
    const query = new URLSearchParams();
    if (filters.id_curso) query.set('id_curso', String(filters.id_curso));
    if (filters.fecha_desde) query.set('fecha_desde', filters.fecha_desde);
    if (filters.fecha_hasta) query.set('fecha_hasta', filters.fecha_hasta);
    return `/api/export/csv?${query.toString()}`;
  },

  // Reset seed data
  async resetSeed(): Promise<void> {
    const res = await fetch('/api/seed/reset', {
      method: 'POST',
      headers: this.getHeaders()
    });
    if (!res.ok) throw new Error('Error al restaurar datos de prueba');
  }
};
