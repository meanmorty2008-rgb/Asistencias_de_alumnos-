import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  isAdmin: boolean;
  isPreceptor: boolean;
  isDocente: boolean;
  canManageCourses: boolean;
  canEditStudents: boolean;
  canTakeAttendance: boolean;
  switchDemoUser: (role: 'admin' | 'preceptor' | 'docente') => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const initAuth = async () => {
      const token = api.getToken();
      if (token) {
        try {
          const res = await api.getMe();
          setUser(res.usuario);
        } catch {
          api.removeToken();
          // Fallback to default admin for smooth evaluation experience
          await loginWithPreset('admin', 'admin123');
        }
      } else {
        // Automatically start with admin account for immediate testability
        await loginWithPreset('admin', 'admin123');
      }
      setLoading(false);
    };

    initAuth();
  }, []);

  const loginWithPreset = async (u: string, p: string) => {
    try {
      const res = await api.login(u, p);
      setUser(res.usuario);
    } catch (e) {
      console.warn('Auto-login error:', e);
    }
  };

  const login = async (username: string, password: string) => {
    const res = await api.login(username, password);
    setUser(res.usuario);
  };

  const logout = async () => {
    await api.logout();
    setUser(null);
  };

  const switchDemoUser = async (role: 'admin' | 'preceptor' | 'docente') => {
    const creds = {
      admin: { u: 'admin', p: 'admin123' },
      preceptor: { u: 'preceptor', p: 'preceptor123' },
      docente: { u: 'docente', p: 'docente123' }
    }[role];
    await login(creds.u, creds.p);
  };

  const isAdmin = user?.rol === 'administrador';
  const isPreceptor = user?.rol === 'preceptor';
  const isDocente = user?.rol === 'docente';

  // Role permissions
  const canManageCourses = isAdmin || isPreceptor;
  const canEditStudents = isAdmin || isPreceptor;
  const canTakeAttendance = true; // All authenticated roles can record attendance

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        logout,
        isAdmin,
        isPreceptor,
        isDocente,
        canManageCourses,
        canEditStudents,
        canTakeAttendance,
        switchDemoUser
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
